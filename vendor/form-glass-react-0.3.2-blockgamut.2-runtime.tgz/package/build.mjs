import fs from 'node:fs';
import {build} from 'esbuild';

// Run npm install, then npm run build in this package directory.
// Existing dist/types provides the shipped API declarations.
for(const format of ['esm','cjs']){
 const extension=format==='esm'?'js':'cjs';
 await build({entryPoints:['./src/library/index.ts'],bundle:true,format,
  external:['react','react-dom','react/jsx-runtime'],jsx:'automatic',
  outfile:`dist/index.${extension}`,loader:{'.png':'dataurl'},minify:true});
 await build({entryPoints:['./src/components/DopplerRangePair.tsx'],bundle:true,format,
  external:['react','react/jsx-runtime'],jsx:'automatic',
  outfile:`dist/range-pair.${extension}`,minify:true});
}
fs.appendFileSync('dist/index.js','\nexport {DopplerRangePair} from "./range-pair.js";\n');
fs.appendFileSync('dist/index.cjs','\nObject.defineProperty(exports,"DopplerRangePair",{enumerable:true,get:()=>require("./range-pair.cjs").DopplerRangePair});\n');
fs.copyFileSync('src/styles/glass.css','dist/styles.css');
