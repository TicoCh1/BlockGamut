export interface GlassIssue {code:'bare-control'|'primary-action'|'unmanaged-dialog';message:string;element:Element;}
/** Read-only, consumer-side contract audit. Diagnostic copies are never controls. */
export function auditGlassUI(root:ParentNode):GlassIssue[]{
  const issues:GlassIssue[]=[];
  for(const element of root.querySelectorAll('button,a[href],input,select,textarea,[role="button"],[role="switch"],[role="checkbox"],[role="dialog"],dialog')){
    if(element.closest('[data-glass-transition-copy],[data-glass-audit-ignore]'))continue;
    if(element.matches('dialog,[role="dialog"]')){
      if(!element.querySelector('[data-glass-component="dialog"]'))issues.push({code:'unmanaged-dialog',message:'Use GlassDialog to own presence and exit animation.',element});
      continue;
    }
    if(element.matches('input[type="hidden"]'))continue;
    if(element.matches('input[type="range"]')&&element.closest('.doppler-range'))continue;
    const surface=element.matches('input,select,textarea')?element.closest('.glass-field[data-glass]'):element.matches('[data-glass]')?element:null;
    if(!surface)issues.push({code:'bare-control',message:'Use a packaged action/input component; CSS classes alone do not install its material.',element});
    else if(surface.getAttribute('data-glass-material')!=='control'&&!surface.hasAttribute('data-glass-specimen'))issues.push({code:'primary-action',message:'Interactive actions use the secondary control material. Mark intentional surface specimens explicitly.',element});
  }
  return issues;
}
