import {useId,type ComponentProps,type InputHTMLAttributes,type TextareaHTMLAttributes} from 'react';
import {Glass,GlassButton as Button,GlassLink as Link,GlassField} from '../components/Glass';
import {foregroundText} from '../components/foregroundText';
import {useGlass} from './GlassProvider';
import {GlassSwitch as Switch} from '../components/GlassSwitch';
import {GlassSelect as Select} from '../components/GlassSelect';

/** Everyday actions cannot accidentally select the primary surface recipe. */
export type GlassButtonProps=Omit<ComponentProps<typeof Button>,'material'|'fade'>;
export function GlassButton(props:GlassButtonProps){useGlass();return <Button {...props} material="control" fade={[]}/>;}
export type GlassLinkProps=Omit<ComponentProps<typeof Link>,'material'|'fade'>;
export function GlassLink(props:GlassLinkProps){useGlass();return <Link {...props} material="control" fade={[]}/>;}
export type GlassPanelProps=Omit<ComponentProps<typeof Glass>,'material'|'reveal'|'onRevealPrepare'|'onRevealCommit'|'onRevealEnd'|'revealOriginBox'>;
export function GlassPanel(props:GlassPanelProps){useGlass();return <Glass {...props} material="surface" data-glass-component="panel"/>;}
export function GlassSwitch(props:ComponentProps<typeof Switch>){useGlass();return <Switch {...props}/>;}
export function GlassSelect(props:ComponentProps<typeof Select>){useGlass();return <Select {...props}/>;}

export interface GlassInputProps extends Omit<InputHTMLAttributes<HTMLInputElement>,'type'> {
  label:string;type?:'text'|'email'|'password'|'search'|'tel'|'url'|'number';hint?:string;
}
export function GlassInput({label,hint,id:provided,type='text',className='',...props}:GlassInputProps){
  useGlass();
  const generated=useId(),id=provided??generated;
  return foregroundText(<label className={`form-glass-input ${className}`} htmlFor={id}>
    <span>{label}</span><GlassField><input {...props} id={id} type={type} aria-label={props['aria-label']??label} aria-describedby={[props['aria-describedby'],hint?`${id}-hint`:''].filter(Boolean).join(' ')||undefined}/></GlassField>
    {hint&&<small id={`${id}-hint`}>{hint}</small>}
  </label>);
}
export interface GlassTextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement>{label:string;hint?:string;}
export function GlassTextarea({label,hint,id:provided,className='',...props}:GlassTextareaProps){
  useGlass();
  const generated=useId(),id=provided??generated;
  return foregroundText(<label className={`form-glass-input ${className}`} htmlFor={id}>
    <span>{label}</span><GlassField><textarea {...props} id={id} aria-label={props['aria-label']??label} aria-describedby={[props['aria-describedby'],hint?`${id}-hint`:''].filter(Boolean).join(' ')||undefined}/></GlassField>
    {hint&&<small id={`${id}-hint`}>{hint}</small>}
  </label>);
}
