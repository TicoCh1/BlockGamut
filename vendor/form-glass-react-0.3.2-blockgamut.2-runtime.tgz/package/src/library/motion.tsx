import {useId,useLayoutEffect,useRef,useState,type ReactNode,type RefObject} from 'react';
import {Glass} from '../components/Glass';
import {GlassButton} from './controls';
import {foregroundText} from '../components/foregroundText';
import {useContentTransition} from '../components/useContentTransition';
import type {GlassGeometry} from '../styles/glass';
import type {RevealBox} from '../styles/revealTimeline';

export interface GlassDialogProps {
  open:boolean;onOpenChange:(open:boolean)=>void;title:string;children:ReactNode;
  className?:string;closeLabel?:string;fade?:GlassGeometry['fade'];originRef?:RefObject<HTMLElement>;
}
/** Keep mounted. Owns native modal presence, motion, Escape and focus return. */
export function GlassDialog({open,onOpenChange,title,children,className='',closeLabel='Close',fade,originRef}:GlassDialogProps){
  const dialog=useRef<HTMLDialogElement>(null),id=useId(),latest=useRef(open);latest.current=open;
  const [present,setPresent]=useState(false),[active,setActive]=useState(false),[moving,setMoving]=useState(false);
  const returnFocus=useRef<HTMLElement|null>(null);
  const origin=useRef<RevealBox|null>(null);
  useLayoutEffect(()=>{
    if(open){
      const source=originRef?.current??(document.activeElement instanceof HTMLElement?document.activeElement:null);
      returnFocus.current=source;
      const rect=source&&source!==document.body?source.getBoundingClientRect():null;
      origin.current=rect&&rect.width&&rect.height?{width:rect.width,height:rect.height,left:rect.left,top:rect.top}:null;
      setMoving(true);setPresent(true);setActive(true);
    }
    else if(present){setMoving(true);setActive(false);}
  },[open]);
  useLayoutEffect(()=>{
    const node=dialog.current;
    if(present&&node&&!node.open)node.showModal();
  },[present]);
  useLayoutEffect(()=>{
    const shell=dialog.current?.querySelector<HTMLElement>('[data-glass-component="dialog"]');
    if(shell)shell.inert=moving;
    if(!moving&&present&&active)dialog.current?.querySelector<HTMLElement>('[data-dialog-close]')?.focus({preventScroll:true});
  },[moving,present,active]);
  return <dialog ref={dialog} className="form-glass-dialog" aria-labelledby={id}
    onCancel={event=>{event.preventDefault();onOpenChange(false);}}>
    <Glass className={`form-glass-dialog-surface ${className}`} fade={fade} data-glass-component="dialog"
      data-glass-entering={moving&&active?'':undefined} reveal={active} revealOriginBox={()=>origin.current}
      onRevealEnd={shown=>{
        if(shown!==latest.current)return;
        setMoving(false);
        const node=dialog.current;
        const shell=node?.querySelector<HTMLElement>('[data-glass-component="dialog"]');if(shell)shell.inert=false;
        if(!shown){node?.close();setPresent(false);returnFocus.current?.focus({preventScroll:true});}
      }}>
      <div className="form-glass-dialog-heading"><h2 id={id}>{title}</h2><GlassButton data-dialog-close="" onClick={()=>onOpenChange(false)}>{closeLabel}</GlassButton></div>
      {children}
    </Glass>
  </dialog>;
}

export interface GlassDisclosureProps {open:boolean;onOpenChange:(open:boolean)=>void;label:string;children:ReactNode;className?:string;fade?:GlassGeometry['fade'];}
/** Preparation/commit and compact geometry are private to the component. */
export function GlassDisclosure({open,onOpenChange,label,children,className='',fade}:GlassDisclosureProps){
  const [shown,setShown]=useState(false),id=useId(),host=useRef<HTMLDivElement>(null);
  return <div ref={host}>
    <Glass className={`form-glass-disclosure ${className}`} fade={fade} reveal={open} data-glass-component="disclosure"
      onRevealPrepare={next=>{
        if(!next&&host.current?.querySelector(`#${CSS.escape(id)}`)?.contains(document.activeElement))host.current.querySelector<HTMLElement>('button')?.focus({preventScroll:true});
        setShown(next);
      }} onRevealCommit={setShown}>
      <GlassButton aria-expanded={open} aria-controls={id} onClick={()=>onOpenChange(!open)}>{label}</GlassButton>
      <div id={id} hidden={!shown}>{shown&&children}</div>
    </Glass>
  </div>;
}

export interface GlassContentSwitchProps {value:string;render:(value:string)=>ReactNode;className?:string;}
/** Owns the displayed key, so outgoing paint is captured before content changes. */
export function GlassContentSwitch({value,render,className=''}:GlassContentSwitchProps){
  const [displayed,setDisplayed]=useState(value),root=useRef<HTMLDivElement>(null);
  // Retain the committed React tree as well as its key. A new render callback
  // may close over the requested route and otherwise replace the outgoing UI
  // before useContentTransition has had a chance to retire it.
  const committed=useRef<ReactNode>(null);
  const content=value===displayed?foregroundText(render(displayed)):committed.current;
  useLayoutEffect(()=>{committed.current=content;});
  useContentTransition(value,root,()=>setDisplayed(value));
  return <div className={`form-glass-content-switch ${className}`} ref={root} data-glass-component="content-switch" data-view={displayed}>{content}</div>;
}
export interface GlassTab {value:string;label:string;content:ReactNode;disabled?:boolean;}
export interface GlassTabsProps {label:string;value:string;onValueChange:(value:string)=>void;tabs:readonly GlassTab[];className?:string;}
export function GlassTabs({label,value,onValueChange,tabs,className=''}:GlassTabsProps){
  const id=useId(),host=useRef<HTMLDivElement>(null);
  const index=tabs.findIndex(tab=>tab.value===value);
  return <div className={`form-glass-tabs ${className}`} ref={host} data-glass-component="tabs">
    <div role="tablist" aria-label={label} className="form-glass-tablist">{tabs.map((tab,i)=><GlassButton key={tab.value} id={`${id}-tab-${i}`} role="tab" disabled={tab.disabled}
      aria-selected={value===tab.value} aria-controls={`${id}-panel`} tabIndex={value===tab.value?0:-1} onClick={()=>onValueChange(tab.value)}
      onKeyDown={event=>{
        if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
        event.preventDefault();const enabled=tabs.map((item,j)=>({item,j})).filter(x=>!x.item.disabled);if(!enabled.length)return;
        const at=enabled.findIndex(x=>x.j===i),target=enabled[event.key==='Home'?0:event.key==='End'?enabled.length-1:(at+(event.key==='ArrowRight'?1:-1)+enabled.length)%enabled.length];
        onValueChange(target.item.value);host.current?.querySelector<HTMLElement>(`[id="${id}-tab-${target.j}"]`)?.focus();
      }}>{tab.label}</GlassButton>)}</div>
    <div id={`${id}-panel`} role="tabpanel" aria-labelledby={`${id}-tab-${index}`} tabIndex={0}>
      <GlassContentSwitch value={value} render={key=>tabs.find(tab=>tab.value===key)?.content}/>
    </div>
  </div>;
}
