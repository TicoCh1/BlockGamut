import {createContext,useContext,useLayoutEffect,useEffect,useMemo,type HTMLAttributes,type ReactNode,type CSSProperties} from 'react';
import {GlassControlScope} from '../components/Glass';
import {auditGlassUI} from './audit';
import {AnimationSettingsProvider} from '../components/AnimationContext';
import {RefractionProvider} from '../components/GlassRefraction';
import {FeatherMaskProvider} from '../components/GlassFeatherMask';
import {ForegroundFade} from '../components/ForegroundFade';
import {TextInversion} from '../components/TextInversion';
import {applyGlassTuning,readGlassDefaults,type GlassValues} from '../styles/glassSettings';
import {setGlassFadeCurve,syncGlassFadeMode,type GlassFadeCurve} from '../styles/glassFade';
import {materialFades} from '../styles/materialFade';
import {DEFAULT_REFRACTION,DEFAULT_REFRACTION_ENABLED,NO_REFRACTION,type RefractionValues} from '../styles/refraction';
import {DEFAULT_ANIMATION_SETTINGS,type AnimationSettings} from '../styles/animationSettings';

export type GlassTextColor='theme'|'black'|'white'|'invert';
export interface GlassProviderProps extends HTMLAttributes<HTMLDivElement> {
  children?:ReactNode;
  theme?:'light'|'dark';
  enabled?:boolean;
  values?:Partial<GlassValues>;
  curve?:GlassFadeCurve;
  textColor?:GlassTextColor;
  fadeContents?:boolean;
  refractionEnabled?:boolean;
  refraction?:Partial<RefractionValues>;
  distortControls?:boolean;
  animations?:AnimationSettings;
  /** Warn about missing material/managed dialogs in the consumer DOM. */
  diagnostics?:boolean;
}
export interface GlassRuntime {
  theme:'light'|'dark';enabled:boolean;values:GlassValues;curve:GlassFadeCurve;
  refractionEnabled:boolean;animations:AnimationSettings;
}
const Context=createContext<GlassRuntime|null>(null);
export function useGlass():GlassRuntime {
  const runtime=useContext(Context);
  if(!runtime)throw new Error('Glass controls requiring runtime settings must be inside GlassProvider.');
  return runtime;
}
let owner:HTMLElement|null=null;
/** One provider per document. A marked root supports any host mounting ID.
 * Never filter/mask this wrapper: nested glass needs the original backdrop. */
export function GlassProvider({children,theme='light',enabled=true,values:overrides,curve='smootherstep',textColor='theme',fadeContents=true,refractionEnabled=DEFAULT_REFRACTION_ENABLED,refraction,distortControls=false,animations=DEFAULT_ANIMATION_SETTINGS,diagnostics=false,className='',style,...props}:GlassProviderProps){
  const values=useMemo(()=>({...readGlassDefaults(theme==='dark'),...overrides}),[theme,overrides]);
  const mirror=useMemo(()=>({...DEFAULT_REFRACTION,...refraction}),[refraction]);
  const fades=materialFades(values);
  const outset=Math.ceil(3*values.blur+2)+Math.max(0,...Object.values(fades).map(fade=>fade.distance>0?fade.distance+fade.mid:0));
  useEffect(()=>{
    if(!diagnostics)return;
    const root=document.querySelector('[data-form-glass-root]');if(!root)return;
    const reported=new WeakMap<Element,string>();let frame=0;
    const scan=()=>{frame=0;for(const issue of auditGlassUI(root)){if(reported.get(issue.element)!==issue.code){reported.set(issue.element,issue.code);console.warn(`[FORM Glass: ${issue.code}] ${issue.message}`,issue.element);}}};
    const observer=new MutationObserver(()=>{if(!frame)frame=requestAnimationFrame(scan);});
    observer.observe(root,{childList:true,subtree:true});scan();
    return()=>{observer.disconnect();cancelAnimationFrame(frame);};
  },[diagnostics]);
  useLayoutEffect(()=>{
    const root=document.documentElement;
    if(owner)throw new Error('Only one GlassProvider may own a document.');
    owner=root;
    const attributes=['data-glass-blur-engine','data-glass-enabled','data-text-color','data-glass-fade-mode','data-glass-fade-curve'];
    const savedAttributes=attributes.map(name=>[name,root.getAttribute(name)] as const);
    const savedStyles=new Map(Array.from(root.style).filter(name=>name.startsWith('--glass-')).map(name=>[name,[root.style.getPropertyValue(name),root.style.getPropertyPriority(name)]] as const));
    const dark=root.classList.contains('theme-dark-root');
    return()=>{
      for(const name of Array.from(root.style).filter(name=>name.startsWith('--glass-')))root.style.removeProperty(name);
      savedStyles.forEach(([value,priority],name)=>root.style.setProperty(name,value,priority));
      savedAttributes.forEach(([name,value])=>value===null?root.removeAttribute(name):root.setAttribute(name,value));
      root.classList.toggle('theme-dark-root',dark);owner=null;
    };
  },[]);
  useLayoutEffect(()=>{
    const root=document.documentElement;
    root.classList.toggle('theme-dark-root',theme==='dark');
    root.dataset.glassBlurEngine='lerp';root.dataset.glassEnabled=String(enabled);root.dataset.textColor=textColor;
    applyGlassTuning(values);setGlassFadeCurve(curve);syncGlassFadeMode();
  },[theme,enabled,textColor,values,curve]);
  return <Context.Provider value={{theme,enabled,values,curve,refractionEnabled,animations}}>
    <AnimationSettingsProvider value={animations}><RefractionProvider value={enabled&&refractionEnabled?mirror:NO_REFRACTION} controls={distortControls}>
      <FeatherMaskProvider value={{active:true,distance:values['fade-distance'],mid:values['fade-mid'],blur:values.blur,curve,fades:materialFades(values)}}>
        <div id="form-glass-root" {...props} style={{'--form-glass-outset':`${outset}px`,...style} as CSSProperties} data-form-glass-root="" className={`form-glass-ui ${className}`}>
          <ForegroundFade active={enabled&&fadeContents} distance={values['fade-distance']} mid={values['fade-mid']} curve={curve}/>
          <TextInversion active={textColor==='invert'} distance={values['fade-distance']} mid={values['fade-mid']} curve={curve} revision={`${theme}/${enabled}/${JSON.stringify(values)}/${curve}/${fadeContents}`}/>
          <GlassControlScope>{children}</GlassControlScope>
        </div>
      </FeatherMaskProvider>
    </RefractionProvider></AnimationSettingsProvider>
  </Context.Provider>;
}
