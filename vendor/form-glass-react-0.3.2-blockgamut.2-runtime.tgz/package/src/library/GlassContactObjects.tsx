import type {ComponentProps} from 'react';
import {GlassContactObjects as ContactScene} from '../components/GlassContactObjects';
import {useGlass} from './GlassProvider';
import {DEFAULT_CONTACT_EXEMPTION,type ContactObject} from '../styles/contactField';

export type GlassContactObjectsProps=Omit<ComponentProps<typeof ContactScene>,'values'|'curve'|'glassEnabled'>;
export function GlassContactObjects(props:GlassContactObjectsProps){
  const {values,curve,enabled}=useGlass();
  return <ContactScene {...props} values={values} curve={curve} glassEnabled={enabled}/>;
}
type ExemptionKey='exempt'|'strength'|'distance'|'mid';
export type ContactObjectInput=Omit<ContactObject,ExemptionKey>&Partial<Pick<ContactObject,ExemptionKey>>;
export function createContactObject(object:ContactObjectInput):ContactObject{return {...DEFAULT_CONTACT_EXEMPTION,...object};}
