import {useLayoutEffect,useRef,type ComponentProps,type CSSProperties} from 'react';
import {Glass,GlassButton} from '../components/Glass';
export interface GlassPosition {x:number;y:number}
export type GlassDraggableProps=Omit<ComponentProps<typeof Glass>,'onChange'> & {
  position:GlassPosition;onPositionChange:(position:GlassPosition)=>void;label?:string;bounds?:'viewport'|'none';
};
/** Controlled position, native pointer capture and keyboard movement. */
export function GlassDraggable({position,onPositionChange,label='Drag to move',bounds='viewport',children,className='',style,...props}:GlassDraggableProps){
  const drag=useRef<{x:number;y:number;origin:GlassPosition}|null>(null);
  const host=useRef<HTMLDivElement>(null),latest=useRef({position,onPositionChange});latest.current={position,onPositionChange};
  const constrain=(next:GlassPosition,node:HTMLElement)=>{
    if(bounds==='none')return next;
    const rect=node.getBoundingClientRect(),renderer=node.querySelector<HTMLElement>(':scope > .glass-renderer');
    const css=renderer?getComputedStyle(renderer):null;
    const inset=(side:string)=>8+(parseFloat(css?.getPropertyValue(`--glass-feather-${side}`)||'0')||0);
    return {x:Math.max(inset('left'),Math.min(innerWidth-rect.width-inset('right'),next.x)),y:Math.max(inset('top'),Math.min(innerHeight-rect.height-inset('bottom'),next.y))};
  };
  useLayoutEffect(()=>{
    const node=host.current;if(!node||bounds==='none')return;
    const fit=()=>{const current=latest.current.position,next=constrain(current,node);if(next.x!==current.x||next.y!==current.y)latest.current.onPositionChange(next);};
    fit();const observer=new ResizeObserver(fit);observer.observe(node);window.addEventListener('resize',fit);
    return()=>{observer.disconnect();window.removeEventListener('resize',fit);};
  },[bounds]);
  const move=(next:GlassPosition,button:HTMLButtonElement)=>{
    onPositionChange(constrain(next,button.parentElement!));
  };
  return <Glass {...props} surfaceRef={host} className={`form-glass-draggable ${className}`} style={{...style,position:'fixed',left:position.x,top:position.y} as CSSProperties}>
    <GlassButton fade={[]} className="form-glass-drag-handle" aria-label={label}
      onPointerDown={e=>{drag.current={x:e.clientX,y:e.clientY,origin:position};e.currentTarget.setPointerCapture(e.pointerId);}}
      onPointerMove={e=>{const d=drag.current;if(d)move({x:d.origin.x+e.clientX-d.x,y:d.origin.y+e.clientY-d.y},e.currentTarget);}}
      onPointerUp={()=>{drag.current=null;}} onPointerCancel={()=>{drag.current=null;}} onLostPointerCapture={()=>{drag.current=null;}}
      onKeyDown={e=>{const step=e.shiftKey?20:8;const d:Record<string,GlassPosition>={ArrowLeft:{x:-step,y:0},ArrowRight:{x:step,y:0},ArrowUp:{x:0,y:-step},ArrowDown:{x:0,y:step}};if(d[e.key]){e.preventDefault();move({x:position.x+d[e.key].x,y:position.y+d[e.key].y},e.currentTarget);}}}>
      {label}<i className="drag-grip" aria-hidden="true"/>
    </GlassButton>{children}
  </Glass>;
}
