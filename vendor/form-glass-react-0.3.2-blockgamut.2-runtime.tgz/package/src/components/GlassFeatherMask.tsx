import { createContext, useContext, useLayoutEffect, useRef, type ReactNode } from 'react';
import { featherMask } from '../styles/featherMask';
import { glassLayoutBox } from '../styles/glassLayout';
import type { GlassFadeCurve } from '../styles/glassFade';
import { alignedMaterialMasks, MATERIAL_CHANNELS, sameMaterialFades, type MaterialFades } from '../styles/materialFade';
import {beginGlassMeasure} from '../styles/performanceProbe';
import {observeMaterialGeometry} from '../styles/geometryBatch';
import {nineSlice,registerNineSlice} from '../styles/nineSlice';

type Settings = { active: boolean; distance: number; mid: number; blur: number; curve: GlassFadeCurve; fades?: MaterialFades };
const FeatherContext = createContext<Settings>({ active: false, distance: 0, mid: 0, blur: 0, curve: 'softmax' });
export function FeatherMaskProvider({ value, children }: { value: Settings; children: ReactNode }) {
  return <FeatherContext.Provider value={value}>{children}</FeatherContext.Provider>;
}

/** Rebuild on layout geometry/parameter changes; scrolling reuses the field. */
export function GlassFeatherMask({ geometryKey }: { geometryKey: string }) {
  const settings = useContext(FeatherContext);
  const anchor = useRef<HTMLSpanElement>(null);
  useLayoutEffect(() => {
    const host = anchor.current?.parentElement;
    const renderer = host?.querySelector<HTMLElement>(':scope > .glass-renderer');
    if (!host || !renderer || !settings.active) return;
    const edges = (host.dataset.glassFade ?? '').split(' ').filter(Boolean);
    if (!edges.length) return;
    const split = settings.fades && !sameMaterialFades(settings.fades);
    const initialStyle = getComputedStyle(host);
    const customCorners = initialStyle.getPropertyValue('--glass-corner-tl').trim() !== '';
    if (!split && settings.distance <= 0 && !customCorners) return;
    let lastKey='';
    const read = (entry?:ResizeObserverEntry) => {
      if(renderer.hasAttribute('data-nine-slice'))return;
      const finish=beginGlassMeasure('featherMask');
      const style = getComputedStyle(host);
      const border=entry?.borderBoxSize?.[0];
      const { width, height } = border?{width:border.inlineSize,height:border.blockSize}:glassLayoutBox(host,style);
      if(!width||!height){finish?.();return;}
      const corners = customCorners ? ['tl','tr','br','bl'].map(corner => parseFloat(style.getPropertyValue(`--glass-corner-${corner}`)) || 0) as [number,number,number,number] : undefined;
      const geometry = { width, height, radius: Math.min(parseFloat(style.getPropertyValue('--glass-radius')) || 0, width / 2, height / 2), corners, edges, blur: settings.blur, curve: settings.curve };
      const key=`${width}/${height}/${geometry.radius}/${corners}`;
      if(key===lastKey){finish?.();return;}
      lastKey=key;
      const complete={...geometry,distance:settings.distance,mid:settings.distance>0?settings.mid:0};
      const mask = split ? alignedMaterialMasks(geometry, settings.fades!) : featherMask(complete);
      const parts=Object.fromEntries(MATERIAL_CHANNELS.map(channel=>{
        const fade=split?settings.fades![channel]:complete;
        return [channel,nineSlice({...geometry,distance:fade.distance,mid:fade.distance>0?fade.mid:0},mask.inset,'urls' in mask?mask.urls[channel]:mask.url)];
      })) as Parameters<typeof registerNineSlice>[1];
      finish?.();
      return ()=>{
      registerNineSlice(renderer,parts);
      if(!renderer.hasAttribute('data-feather-mask'))renderer.dataset.featherMask = '';
      if ('urls' in mask) {
        renderer.dataset.separateFades = '';
        const layers = renderer.querySelectorAll<HTMLElement>('.glass-blur-layer');
        MATERIAL_CHANNELS.forEach((channel, i) => {
          layers[i + 5].style.setProperty('--glass-channel-mask', mask.urls[channel]);
          layers[i + 5].toggleAttribute('data-empty-feather', mask.empty[channel]);
        });
        renderer.style.setProperty('--glass-feather-mask', mask.urls.blur);
      } else { renderer.style.setProperty('--glass-feather-mask', mask.url); renderer.toggleAttribute('data-empty-feather', mask.empty); }
      ['top', 'right', 'bottom', 'left'].forEach((e, i) => {const value=`${mask.inset[i]}px`,key=`--glass-feather-${e}`;if(renderer.style.getPropertyValue(key)!==value)renderer.style.setProperty(key,value);});
      };
    };
    const measure=()=>read()?.();
    measure();
    host.addEventListener('glassgeometrychange',measure);
    const disconnect=observeMaterialGeometry(host,read);
    return () => {
      disconnect(); delete renderer.dataset.featherMask; delete renderer.dataset.separateFades; delete renderer.dataset.emptyFeather;
      host.removeEventListener('glassgeometrychange',measure);
      renderer.querySelectorAll<HTMLElement>('.glass-blur-layer').forEach(layer => { layer.style.removeProperty('--glass-channel-mask'); delete layer.dataset.emptyFeather; });
      renderer.style.removeProperty('--glass-feather-mask');
      ['top', 'right', 'bottom', 'left'].forEach(e => renderer.style.removeProperty(`--glass-feather-${e}`));
    };
  }, [settings.active, settings.distance, settings.mid, settings.blur, settings.curve, settings.fades?.brightness.distance, settings.fades?.brightness.mid, settings.fades?.contrast.distance, settings.fades?.contrast.mid, geometryKey]);
  return <span ref={anchor} hidden aria-hidden="true" />;
}
