import {revealContentFrames} from '../styles/revealTimeline';
import {animationContentTiming,type AnimationSettings} from '../styles/animationSettings';

type ForegroundElement=HTMLElement|SVGElement;
export function foregroundRoots(host:HTMLElement){
  return Array.from(host.children).filter((n):n is ForegroundElement=>(n instanceof HTMLElement||n instanceof SVGElement)&&!n.hasAttribute('hidden')&&!n.matches('.glass-renderer,.glass-reveal-defs,.glass-refraction-defs'));
}
export function announcePhase(host:HTMLElement,phase:string,detail:Record<string,unknown>={}){
  host.dataset.glassRevealPhase=phase;
  host.dispatchEvent(new CustomEvent('glassrevealphase',{bubbles:true,detail:{phase,...detail}}));
}
/** Animate the real foreground once. No cloned controls, duplicate observers,
 * or offscreen backdrop filters. The caller owns the phase boundaries. */
export function foregroundMotion(roots:ForegroundElement[],hiding:boolean,settings:AnimationSettings,signal:AbortSignal,hosts:HTMLElement[]=[]){
  const timing=animationContentTiming(settings,hiding),limit=settings.values['content-blur'];
  const animations=roots.map(root=>{
    // Interruptions start at the currently painted frame, never at opacity 1.
    const style=getComputedStyle(root),opacity=Number(style.opacity),blur=Number(style.filter.match(/blur\(([\d.]+)px\)/)?.[1]??0);
    const frames=revealContentFrames(hiding?opacity:0,hiding?0:1,hiding?blur:limit,hiding?limit:0,timing);
    const animation=root.animate(frames,{duration:timing.duration,easing:'linear',fill:'both'});animation.pause();animation.currentTime=0;return animation;
  });
  const cancel=()=>animations.forEach(animation=>animation.cancel());
  signal.addEventListener('abort',cancel,{once:true});
  const finished=nextPaint(signal).then(start=>{
    animations.forEach(animation=>{animation.play();animation.startTime=start;});
    hosts.forEach(host=>host.dispatchEvent(new CustomEvent('glassrevealphase',{bubbles:true,detail:{phase:hiding?'hiding':'showing',duration:timing.duration,startTime:start,blurLimit:limit,contentTiming:timing,sequential:true}})));
    return Promise.all(animations.map(animation=>animation.finished));
  });
  return {finished,
    // Transfer paint ownership before aborting an interrupted transition. The
    // next owner installs its first frame before cancelling this held frame.
    freeze:()=>{signal.removeEventListener('abort',cancel);animations.forEach(animation=>animation.pause());},
    cancel:()=>{signal.removeEventListener('abort',cancel);cancel();},duration:timing.duration};
}
export function nextPaint(signal:AbortSignal){
  return new Promise<number>((resolve,reject)=>{
    if(signal.aborted){reject(new DOMException('Aborted','AbortError'));return;}
    const stop=()=>{cancelAnimationFrame(frame);reject(new DOMException('Aborted','AbortError'));};
    const frame=requestAnimationFrame(time=>{signal.removeEventListener('abort',stop);resolve(time);});
    signal.addEventListener('abort',stop,{once:true});
  });
}
