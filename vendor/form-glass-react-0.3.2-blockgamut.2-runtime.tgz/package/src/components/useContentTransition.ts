import {useLayoutEffect,useRef,type RefObject} from 'react';
import {flushSync} from 'react-dom';
import {useAnimationSettings} from './AnimationContext';
import {foregroundMotion,nextPaint} from './foregroundMotion';

/** Content switches retire the current tree before mounting the next tree. */
export function useContentTransition(key:string,root:RefObject<HTMLElement>,onSwap:()=>void,extras=''){
  const settings=useAnimationSettings(),latest=useRef({settings,onSwap});latest.current={settings,onSwap};
  const previous=useRef(key);
  const requested=useRef(key);requested.current=key;
  const handoff=useRef<ReturnType<typeof foregroundMotion>>();
  const originals=useRef(new Map<HTMLElement,{opacity:string;inert:boolean}>());
  useLayoutEffect(()=>{
    if(previous.current===key)return;previous.current=key;
    const abort=new AbortController(),signal=abort.signal;
    let paint:ReturnType<typeof foregroundMotion>|undefined,completed=false;
    const collect=()=>[...(root.current?[root.current]:[]),...(extras?Array.from(document.querySelectorAll<HTMLElement>(extras)):[])];
    const mark=(hidden:boolean)=>collect().forEach(node=>{if(!originals.current.has(node))originals.current.set(node,{opacity:node.style.opacity,inert:node.inert});node.inert=true;node.dataset.glassContentPhase=hidden?'moving':'hiding';if(hidden)node.style.opacity='0';});
    const releaseHandoff=()=>{handoff.current?.cancel();handoff.current=undefined;};
    const restore=()=>{originals.current.forEach(({opacity,inert},node)=>{node.style.opacity=opacity;node.inert=inert;delete node.dataset.glassContentPhase;});originals.current.clear();};
    const run=async()=>{
      if(matchMedia('(prefers-reduced-motion: reduce)').matches){flushSync(()=>latest.current.onSwap());completed=true;restore();releaseHandoff();return;}
      mark(false);paint=foregroundMotion(collect(),true,latest.current.settings,signal,collect());releaseHandoff();await paint.finished;if(signal.aborted)return;
      mark(true);paint.cancel();paint=undefined;
      flushSync(()=>latest.current.onSwap());mark(true);
      root.current?.dispatchEvent(new CustomEvent('glassrevealphase',{bubbles:true,detail:{phase:'settling'}}));
      await nextPaint(signal);await nextPaint(signal);
      collect().forEach(node=>{node.dataset.glassContentPhase='showing';});
      paint=foregroundMotion(collect(),false,latest.current.settings,signal,collect());await paint.finished;if(signal.aborted)return;
      completed=true;restore();paint.cancel();paint=undefined;
      root.current?.dispatchEvent(new CustomEvent('glassrevealphase',{bubbles:true,detail:{phase:'idle'}}));
    };
    void nextPaint(signal).then(run).catch(error=>{if(!signal.aborted&&error?.name!=='AbortError'){restore();paint?.cancel();releaseHandoff();console.error('Content transition failed',error);}});
    return()=>{
      if(!completed&&requested.current!==key){
        // Keep the outgoing frame (or the transparent swap boundary) until
        // the replacement transition takes ownership. Cleanup must not reveal.
        if(paint){paint.freeze();releaseHandoff();handoff.current=paint;}
        abort.abort();
      }else{abort.abort();paint?.cancel();releaseHandoff();restore();}
    };
  },[key,root,extras]);
}
