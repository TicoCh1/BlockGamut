import { useLayoutEffect, useRef, useState } from 'react';
import { rangeLobes, rangeLobePath, rangeMotionForSpeed, RANGE_PROFILE } from '../styles/rangeShape';
import { advanceRangeSpring } from '../styles/rangeSpring';

/** Native range behavior, with a vector indicator whose trailing lobe stretches
 * in the direction opposite to the value's motion. Idle work stops entirely. */
export function DopplerRange({ label, value, min, max, step, disabled, onChange, onPreview, clip, limits, valueText, rail=true }: {
  valueText?:string; clip?:[number,number]; limits?:[number,number]; rail?:boolean; label:string; value:number; min:number; max:number; step:number; disabled?:boolean; onChange:(value:number)=>void; onPreview?:(value:number)=>void;
}) {
  const host = useRef<HTMLSpanElement>(null);
  const [width,setWidth] = useState(200), [motion,setMotion] = useState(0), [preview,setPreview] = useState(value);
  const activity = useRef({ value, time:0, timer:0, frame:0, frameTime:0, motion:0, velocity:0, target:0, pending:false, pointer:null as number|null, pointerX:0, pointerTime:0 });
  const callbacks = useRef({ onChange, onPreview });
  callbacks.current = { onChange, onPreview };
  // Pointer/keyboard movement only changes this control. Expensive material
  // updates run once on release, using the latest draft rather than React's
  // possibly batched last render. Window listeners also handle release outside.
  function commit() {
    const state=activity.current;
    state.pointer=null;
    if (state.pending) { state.pending=false; callbacks.current.onChange(state.value); }
    settle();
  }
  function settle() {
    clearTimeout(activity.current.timer);
    retarget(0);
  }
  function retarget(target:number) {
    const state=activity.current;
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) {
      cancelAnimationFrame(state.frame); state.frame=0; state.target=0; state.motion=0; state.velocity=0; setMotion(0); return;
    }
    state.target=target;
    if (state.frame || target===state.motion && state.velocity===0) return;
    state.frameTime=performance.now();
    const tick = (now:number) => {
      const next=advanceRangeSpring({position:state.motion,velocity:state.velocity},state.target,(now-state.frameTime)/1000);
      state.frameTime=now; state.motion=next.position; state.velocity=next.velocity;
      if (Math.abs(state.motion-state.target)<.002 && Math.abs(state.velocity)<.04) {
        state.motion=state.target; state.velocity=0; state.frame=0; setMotion(state.target);
      } else { setMotion(state.motion); state.frame=requestAnimationFrame(tick); }
    };
    state.frame=requestAnimationFrame(tick);
  }
  function speed(pixelsPerSecond:number) {
    clearTimeout(activity.current.timer);
    retarget(rangeMotionForSpeed(pixelsPerSecond));
    activity.current.timer=window.setTimeout(settle,100);
  }
  function change(next:number) {
    next=Math.max(limits?.[0]??min,Math.min(limits?.[1]??max,next));
    const state=activity.current, now=performance.now();
    const dt=Math.min(64,Math.max(16,now-state.time)), delta=(next-state.value)/(max-min)*width;
    // Real pointer velocity drives pointer gestures; value deltas are only
    // a fallback for keyboard/assistive input, never a quantized drag signal.
    if (state.pointer===null || state.pointer===-1) speed(delta/dt*1000);
    setPreview(next); state.value=next; state.time=now; state.pending=true;
    callbacks.current.onPreview?.(next);
  }
  useLayoutEffect(()=>{
    const node=host.current;
    if (!node) return;
    const observer=new ResizeObserver(entries=>{
      const measured=entries[0]?.contentRect.width??0;
      // A suspended foreground must not turn hidden zero-size notifications
      // into React renders (or destroy its cached slider geometry).
      if(measured>0&&!node.closest('[data-glass-reveal-phase="moving"]'))setWidth(measured);
    }); observer.observe(node);
    const release=(event:PointerEvent)=>{ if (activity.current.pointer===event.pointerId) commit(); };
    window.addEventListener('pointerup',release); window.addEventListener('pointercancel',release);
    window.addEventListener('blur',commit);
    return ()=>{ observer.disconnect(); clearTimeout(activity.current.timer); cancelAnimationFrame(activity.current.frame); window.removeEventListener('pointerup',release); window.removeEventListener('pointercancel',release); window.removeEventListener('blur',commit); };
  },[]);
  useLayoutEffect(()=>{ if (!activity.current.pending) { activity.current.value=value; setPreview(value); } },[value]);
  const centre=6+(width-12)*(preview-min)/(max-min);
  const lobes=rangeLobes(motion);
  const atMin=preview<=min, atMax=preview>=max;
  const left=atMin?0:Math.min(lobes.left,centre+8), right=atMax?0:Math.min(lobes.right,width-centre+8);
  return <div className="range-field range-no-glass"><span className="doppler-range" ref={host} data-direction={motion>0?'right':motion<0?'left':'rest'}>
    <svg className="doppler-track" style={{'--range-stroke':RANGE_PROFILE.stroke} as React.CSSProperties} viewBox={`0 0 ${width} 26`} preserveAspectRatio="none" aria-hidden="true">
      {/* The constant-width rail continues beneath each flare to its mouth.
          Stretching the filled arc can never taper below the rail thickness. */}
      {rail&&<path className="doppler-line" d={`${atMin?'':`M1 13H${Math.max(1,centre-RANGE_PROFILE.gap)}`}${atMax?'':`M${Math.min(width-1,centre+RANGE_PROFILE.gap)} 13H${width-1}`}`} />}
      <g transform={`translate(${centre} 13)`} data-tail-left={left} data-tail-right={right}>
        {!atMin&&<path className="doppler-lobe" d={rangeLobePath(left,lobes.leftHeight)} />}
        {!atMax&&<path className="doppler-lobe" transform="scale(-1 1)" d={rangeLobePath(right,lobes.rightHeight)} />}
        <path className="doppler-mouth" d={`${atMin?'':`M${-RANGE_PROFILE.gap} ${-lobes.leftHeight}V${lobes.leftHeight}`}${atMax?'':`M${RANGE_PROFILE.gap} ${-lobes.rightHeight}V${lobes.rightHeight}`}`} />
        <path className="doppler-centre" d={`M0 ${-RANGE_PROFILE.centreHalf}V${RANGE_PROFILE.centreHalf}`} />
      </g>
    </svg>
    <input style={clip?{clipPath:`inset(0 ${100-clip[1]}% 0 ${clip[0]}%)`}:undefined} aria-label={label} aria-valuetext={valueText} type="range" min={min} max={max} step={step} value={preview} disabled={disabled}
      onPointerDown={event=>{ const state=activity.current;state.pointer=event.pointerId;state.time=performance.now();state.pointerX=event.clientX;state.pointerTime=event.timeStamp; }}
      onPointerMove={event=>{ const state=activity.current;if(state.pointer!==event.pointerId)return;const dt=event.timeStamp-state.pointerTime;if(dt>0)speed((event.clientX-state.pointerX)/dt*1000);state.pointerX=event.clientX;state.pointerTime=event.timeStamp; }}
      onChange={event=>{ event.target.value=String(Math.max(limits?.[0]??min,Math.min(limits?.[1]??max,Number(event.target.value)))); change(Number(event.target.value)); if (activity.current.pointer===null) commit(); }}
      onKeyDown={event=>{ if (['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End','PageUp','PageDown'].includes(event.key)) activity.current.pointer=-1; }}
      onKeyUp={commit} onBlur={commit}/>
  </span></div>;
}
