import {useLayoutEffect,useRef} from 'react';
import {GlassButton} from './Glass';
import {clampContactPosition,type ContactObject} from '../styles/contactField';
import {createContactCompositor} from '../styles/contactCompositor';
import type {GlassValues} from '../styles/glassSettings';
import type {GlassFadeCurve} from '../styles/glassFade';
export function GlassContactObjects({values,curve,glassEnabled,objects,onChange,selectedId,onSelect}:{values:GlassValues;curve:GlassFadeCurve;glassEnabled:boolean;objects:ContactObject[];onChange:(objects:ContactObject[])=>void;selectedId?:string;onSelect?:(id:string)=>void}) {
  const state={objects,setObjects:onChange,selected:selectedId,select:onSelect??(()=>{})},world=useRef<HTMLCanvasElement>(null);
  const model=useRef(state.objects),renderer=useRef<ReturnType<typeof createContactCompositor>|null>(null);
  const drag=useRef<{id:string;x:number;y:number;originX:number;originY:number}|null>(null);
  useLayoutEffect(()=>{model.current=state.objects;renderer.current?.schedule();},[state.objects]);
  useLayoutEffect(()=>{
    const compositor=createContactCompositor(world.current!,()=>model.current,{values,curve,glassEnabled});
    renderer.current=compositor;
    return()=>{compositor.destroy();renderer.current=null;};
  },[values,curve,glassEnabled]);
  function move(id:string,x:number,y:number,target:HTMLElement) {
    model.current=model.current.map(o=>o.id===id?{...o,...clampContactPosition(x,y,o.width,o.height,innerWidth,innerHeight)}:o);
    const object=model.current.find(o=>o.id===id)!;
    target.style.left=`${object.x}px`;target.style.top=`${object.y+object.height+6}px`;
    renderer.current?.schedule();
  }
  function finish() { if(drag.current){drag.current=null;state.setObjects([...model.current]);} }
  useLayoutEffect(()=>{window.addEventListener('blur',finish);return()=>window.removeEventListener('blur',finish);});
  return <><canvas ref={world} className="contact-world-paint" aria-hidden="true"/>{state.objects.map((object,i)=><GlassButton key={object.id} className="contact-drag-handle" fade={[]} aria-label={`Drag ${object.label}`} aria-pressed={object.id===state.selected} style={{left:object.x,top:object.y+object.height+6,width:object.width}} onPointerDown={e=>{state.select(object.id);const o=model.current.find(o=>o.id===object.id)!;drag.current={id:o.id,x:e.clientX,y:e.clientY,originX:o.x,originY:o.y};e.currentTarget.setPointerCapture(e.pointerId);}} onPointerMove={e=>{const d=drag.current;if(d?.id===object.id)move(d.id,d.originX+e.clientX-d.x,d.originY+e.clientY-d.y,e.currentTarget);}} onPointerUp={finish} onPointerCancel={finish} onLostPointerCapture={finish} onKeyDown={e=>{const delta:Record<string,[number,number]>={ArrowLeft:[-8,0],ArrowRight:[8,0],ArrowUp:[0,-8],ArrowDown:[0,8]};if(delta[e.key]){e.preventDefault();state.select(object.id);const o=model.current.find(o=>o.id===object.id)!;move(o.id,o.x+delta[e.key][0],o.y+delta[e.key][1],e.currentTarget);state.setObjects([...model.current]);}}}>{String(i+1).padStart(2,'0')} / {object.label}<i className="drag-grip" aria-hidden="true"/></GlassButton>)}</>;
}
