import {getGlassRoot} from '../styles/glassRoot';
import { useId, useLayoutEffect, useRef, useState, type ReactNode, type RefObject } from 'react';
import { scrollFromThumb, scrollGeometry } from '../styles/scrollbar';

type Geometry = ReturnType<typeof scrollGeometry>;
const EMPTY = scrollGeometry(0, 0, 0, 0);

function useScrollControl(viewport: RefObject<HTMLDivElement> | null, rail: RefObject<HTMLDivElement>) {
  const [geometry, setGeometry] = useState(EMPTY);
  const measured = useRef(EMPTY);
  const move = (position: number) => {
    if (viewport) viewport.current?.scrollTo({ top: position, behavior: 'auto' });
    else window.scrollTo({ top: position, behavior: 'auto' });
  };
  useLayoutEffect(() => {
    const element = viewport ? viewport.current : document.scrollingElement as HTMLElement;
    if (!element) return;
    let frame = 0;
    const measure = () => {
      frame = 0;
      const height = viewport ? element.clientHeight : window.innerHeight;
      const track = rail.current?.getBoundingClientRect().height ?? 0;
      const next = scrollGeometry(height, element.scrollHeight, element.scrollTop, track, viewport ? 40 : 48);
      measured.current = next;
      setGeometry(old => Object.keys(next).every(key => old[key as keyof Geometry] === next[key as keyof Geometry]) ? old : next);
    };
    const schedule = () => { if (!frame) frame = requestAnimationFrame(measure); };
    const scrollTarget = viewport ? element : window;
    scrollTarget.addEventListener('scroll', schedule, { passive: true });
    window.addEventListener('resize', schedule);
    const observer = new ResizeObserver(schedule);
    observer.observe(element);
    observer.observe(viewport ? element.firstElementChild ?? element : getGlassRoot());
    if (rail.current) observer.observe(rail.current);
    measure();
    return () => {
      cancelAnimationFrame(frame); observer.disconnect();
      scrollTarget.removeEventListener('scroll', schedule); window.removeEventListener('resize', schedule);
    };
  }, [viewport, rail]);
  return { geometry, measured, move, pageSize: () => viewport ? viewport.current?.clientHeight ?? 0 : window.innerHeight };
}

function ScrollRail({ control, rail, controls, label, page = false }: {
  control: ReturnType<typeof useScrollControl>; rail: RefObject<HTMLDivElement>; controls: string; label: string; page?: boolean;
}) {
  const { geometry, measured, move, pageSize } = control;
  const drag = useRef<{ y: number; offset: number } | null>(null);
  const [dragging, setDragging] = useState(false);
  return <div ref={rail} className={`glass-scroll-rail${page ? ' page-scroll-rail' : ''}`} data-visible={geometry.visible} data-dragging={dragging} onPointerDown={event => {
    if (!geometry.visible || event.button !== 0 || (event.target as Element).closest('[role="scrollbar"]')) return;
    const rect = event.currentTarget.getBoundingClientRect();
    move(scrollFromThumb(event.clientY - rect.top - geometry.length / 2, geometry.range, geometry.travel));
  }}>
    {geometry.visible && <div className="glass-scroll-thumb" tabIndex={0}
      role="scrollbar" aria-label={label} aria-controls={controls} aria-orientation="vertical" aria-valuemin={0} aria-valuemax={Math.round(geometry.range)} aria-valuenow={Math.round(geometry.value)} aria-valuetext={`${Math.round(100 * geometry.value / geometry.range)}% scrolled`}
      style={{ height: geometry.length, transform: `translateY(${geometry.offset}px)` }}
      onPointerDown={event => {
        if (event.button !== 0) return;
        event.preventDefault(); event.stopPropagation(); event.currentTarget.focus({ preventScroll: true });
        event.currentTarget.setPointerCapture(event.pointerId);
        drag.current = { y: event.clientY, offset: measured.current.offset }; setDragging(true);
      }}
      onPointerMove={event => {
        if (!drag.current) return;
        const current = measured.current;
        move(scrollFromThumb(drag.current.offset + event.clientY - drag.current.y, current.range, current.travel));
      }}
      onPointerUp={event => { drag.current = null; setDragging(false); if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId); }}
      onPointerCancel={() => { drag.current = null; setDragging(false); }}
      onLostPointerCapture={() => { drag.current = null; setDragging(false); }}
      onKeyDown={event => {
        const current = measured.current;
        const positions: Record<string, number> = { ArrowUp: current.value - 40, ArrowDown: current.value + 40, PageUp: current.value - pageSize() * .9, PageDown: current.value + pageSize() * .9, Home: 0, End: current.range };
        if (event.key in positions) { event.preventDefault(); move(Math.max(0, Math.min(current.range, positions[event.key]))); }
      }}><i className="scroll-grip" aria-hidden="true" /></div>}
  </div>;
}

/** Native scrolling owns the content; only the visual scrollbar is replaced. */
export function GlassScrollArea({ children, className = '', viewportClassName = '', label = 'Scroll content', height, maxHeight }: {
  children: ReactNode; className?: string; viewportClassName?: string; label?: string; height?:number|string; maxHeight?:number|string;
}) {
  const viewport = useRef<HTMLDivElement>(null), rail = useRef<HTMLDivElement>(null);
  const id = useId();
  const control = useScrollControl(viewport, rail);
  return <div className={`glass-scroll-area ${className}`}>
    <div ref={viewport} id={id} className={`glass-scroll-viewport ${viewportClassName}`} style={{height,maxHeight}}><div className="glass-scroll-body">{children}</div></div>
    <ScrollRail control={control} rail={rail} controls={id} label={label} />
  </div>;
}

export function GlassPageScrollbar() {
  const rail = useRef<HTMLDivElement>(null);
  const [controls,setControls] = useState('root');
  const control = useScrollControl(null, rail);
  useLayoutEffect(() => {
    setControls(getGlassRoot().id || 'root');
    document.documentElement.dataset.glassScrollbars = '';
    return () => { delete document.documentElement.dataset.glassScrollbars; };
  }, []);
  return <ScrollRail control={control} rail={rail} controls={controls} label="Scroll page" page />;
}
