import { Children, cloneElement, createElement, isValidElement, type ReactNode } from 'react';

// A separate paint target keeps blend/mask effects off containers that contain
// backdrop-filter controls. Custom inline tags also preserve existing span selectors.
export function foregroundText(children: ReactNode): ReactNode {
  const grouped: ReactNode[] = [];
  Children.toArray(children).forEach(child => {
    const last = grouped[grouped.length - 1];
    if ((typeof child === 'string' || typeof child === 'number') && (typeof last === 'string' || typeof last === 'number')) grouped[grouped.length - 1] = `${last}${child}`;
    else grouped.push(child);
  });
  return Children.map(grouped, child => {
    if (typeof child === 'string' || typeof child === 'number') {
      return createElement('glass-text', { 'data-glass-text': '' }, child);
    }
    if (!isValidElement<{ children?: ReactNode; className?: string }>(child)) return child;
    if (typeof child.type === 'string' && ['glass-text', 'svg', 'select', 'option', 'textarea', 'script', 'style'].includes(child.type)) return child;
    if (child.props.className?.split(' ').includes('type-backdrop')) return child;
    if (child.props.children === undefined) return child;
    return cloneElement(child, undefined, foregroundText(child.props.children));
  });
}
