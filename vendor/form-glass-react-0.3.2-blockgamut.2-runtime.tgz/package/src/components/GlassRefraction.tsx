import { createContext, useContext, useId, useLayoutEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { displacementMap, displacementScale, NO_REFRACTION, mirrorGeometry, mirrorCornerRadii, selectedRefractionEdges, type RefractionEdge, type RefractionGeometry, type CornerRadii, type RefractionValues } from '../styles/refraction';
import { glassLayoutBox } from '../styles/glassLayout';

const RefractionContext = createContext({ values: NO_REFRACTION, fade: 0, controls: false });

/** One observer for the entire app, and only fade changes trigger measurement.
 * Blur/tone changes stay in CSS and do not fan out into layout reads. */
export function RefractionProvider({ value, children, controls = false }: { value: RefractionValues; children: ReactNode; controls?: boolean }) {
  const [fade, setFade] = useState(0);
  useLayoutEffect(() => {
    if(value.strength<=0)return;
    const root = document.documentElement;
    const read = () => {
      const next = parseFloat(getComputedStyle(root).getPropertyValue('--glass-fade-distance')) || 0;
      setFade(old => old === next ? old : next);
    };
    read();
    const observer = new MutationObserver(read);
    observer.observe(root, { attributes: true, attributeFilter: ['style'] });
    return () => observer.disconnect();
  }, [value.strength>0]);
  const context = useMemo(() => ({ values: value, fade, controls }), [value, fade, controls]);
  return <RefractionContext.Provider value={context}>{children}</RefractionContext.Provider>;
}

/** Optional displacement for the processed glass backdrop. The selected engine
 * chooses its pass; rounded/fade masks and foreground content stay unchanged. */
export function GlassRefraction({ control = false, edges }: { control?: boolean; edges?: readonly RefractionEdge[] }) {
  const { values, fade, controls } = useContext(RefractionContext);
  const filterId = `glass-edge-${useId().replaceAll(':', '')}`;
  const defs = useRef<SVGSVGElement>(null);
  const [geometry, setGeometry] = useState<RefractionGeometry>({ width: 0, height: 0, offsetX: 0, offsetY: 0, renderWidth: 0, renderHeight: 0, corners: [0,0,0,0] });
  const edgeKey=selectedRefractionEdges(edges).join(' ');
  const active = values.strength > 0 && (!control || controls) && edgeKey.length>0;
  useLayoutEffect(() => {
    const host = defs.current?.parentElement;
    const renderer = host?.querySelector<HTMLElement>(':scope > .glass-renderer');
    if (!host || !renderer || !active) return;
    const measure = () => {
      const style=getComputedStyle(host);
      const rect=glassLayoutBox(host,style),rendererStyle=getComputedStyle(renderer),rendered=glassLayoutBox(renderer,rendererStyle);
      const radius=parseFloat(style.getPropertyValue('--glass-radius'))||0;
      const outlineCorners=['tl','tr','br','bl'].map(corner=>{const custom=style.getPropertyValue(`--glass-corner-${corner}`).trim();return Math.max(0,Math.min(custom!==''?parseFloat(custom)||0:radius,rect.width/2,rect.height/2));}) as unknown as CornerRadii;
      const reflectedEdges=edgeKey.split(' ') as RefractionEdge[];
      const corners=mirrorCornerRadii(rect.width,rect.height,outlineCorners,reflectedEdges,fade>0?values.cornerRadius:0);
      const next = { corners, outlineCorners, edges:reflectedEdges, width: rect.width, height: rect.height, offsetX:-(parseFloat(rendererStyle.left)||0), offsetY:-(parseFloat(rendererStyle.top)||0), renderWidth: rendered.width, renderHeight: rendered.height };
      setGeometry(old => ['width','height','offsetX','offsetY','renderWidth','renderHeight'].every(key=>old[key as keyof RefractionGeometry]===next[key as keyof RefractionGeometry])&&corners.every((r,i)=>r===old.corners?.[i])&&outlineCorners.every((r,i)=>r===old.outlineCorners?.[i])&&old.edges?.join(' ')===edgeKey?old:next);
    };
    host.dataset.edgeDistortion = '';
    host.style.setProperty('--glass-edge-filter', `url(#${filterId})`);
    measure();
    const resize = new ResizeObserver(measure); resize.observe(host); resize.observe(renderer);
    return () => { resize.disconnect(); delete host.dataset.edgeDistortion; host.style.removeProperty('--glass-edge-filter'); };
  }, [active, filterId, fade, edgeKey, values.cornerRadius]);
  const map = useMemo(() => active && geometry.width > 0 && geometry.height > 0 ? displacementMap(geometry, values) : null, [active, geometry, values.width, values.transition, values.profile, values.axisBend, values.bendSpan]);
  if (!active) return null;
  return <svg ref={defs} className="glass-refraction-defs" width="0" height="0" aria-hidden="true" data-refraction-strength={values.strength} data-refraction-width={values.width} data-refraction-model="outline-mirror" data-refraction-edges={edgeKey} data-refraction-corners={geometry.corners?.join(',')} data-refraction-outline-corners={geometry.outlineCorners?.join(',')} data-refraction-effective-axis={mirrorGeometry(geometry.width,geometry.height,values,geometry.corners).axis} data-refraction-transition={values.transition} data-refraction-profile={values.profile} data-refraction-axis-bend={values.axisBend} data-refraction-bend-span={values.bendSpan} data-refraction-softness={values.softness}><defs>
    <filter id={filterId} x="0" y="0" width={geometry.renderWidth} height={geometry.renderHeight} filterUnits="userSpaceOnUse" primitiveUnits="userSpaceOnUse" colorInterpolationFilters="sRGB">
      <feImage href={map ?? undefined} x="0" y="0" width={geometry.renderWidth} height={geometry.renderHeight} preserveAspectRatio="none" result="edgeMap" />
      {values.softness > 0 && <feGaussianBlur in="edgeMap" stdDeviation={values.softness} edgeMode="duplicate" result="softMap" />}
      <feComponentTransfer in={values.softness > 0 ? 'softMap' : 'edgeMap'} result="normals"><feFuncR type="linear" slope={255 / 254} intercept={-1 / 254} /><feFuncG type="linear" slope={255 / 254} intercept={-1 / 254} /></feComponentTransfer>
      <feDisplacementMap in="SourceGraphic" in2="normals" scale={displacementScale(geometry.width, geometry.height, values, geometry.corners)} xChannelSelector="R" yChannelSelector="G" />
    </filter>
  </defs></svg>;
}
