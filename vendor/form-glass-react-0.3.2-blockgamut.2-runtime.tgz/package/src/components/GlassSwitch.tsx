import { GlassButton } from './Glass';

type Props = {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
  ariaLabel?: string;
  className?: string;
};

/** A text-only glass bubble; its internal light communicates the enabled state. */
export function GlassSwitch({ label, checked, onChange, ariaLabel, className = '' }: Props) {
  return <GlassButton className={`glass-state-switch ${className}`} shape="capsule" fade={[]}
    role="switch" aria-label={ariaLabel ?? label} aria-checked={checked}
    onClick={() => onChange(!checked)}>
    <span className="glass-switch-light" aria-hidden="true" />
    <span className="glass-switch-label">{label}</span>
  </GlassButton>;
}
