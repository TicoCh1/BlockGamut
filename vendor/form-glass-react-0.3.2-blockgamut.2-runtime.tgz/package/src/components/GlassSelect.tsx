import { useId, useLayoutEffect, useRef, useState, type KeyboardEvent } from 'react';
import { Glass, GlassButton } from './Glass';
import { GlassScrollArea } from './GlassScrollArea';

type Option = { value: string; label: string };
type Anchor = { left: number; top: number; bottom: number; width: number; height: number; down: boolean };

/** The selected row is the trigger: keep it pinned while the other rows unfold. */
export function GlassSelect({ label, value, options, onChange, disabled = false }: {
  label: string; value: string; options: readonly Option[]; onChange: (value: string) => void; disabled?: boolean;
}) {
  const id = useId(), menu = useRef<HTMLDivElement>(null), trigger = useRef<HTMLSpanElement>(null);
  const [open, setOpen] = useState(false), [present, setPresent] = useState(false), [expanded, setExpanded] = useState(false);
  const [active, setActive] = useState(0), [anchorIndex, setAnchorIndex] = useState(0), [down, setDown] = useState(true);
  const anchor = useRef<Anchor | null>(null), returnFocus = useRef(false), keyboardNavigation = useRef(false);
  const typeahead = useRef({ text: '', time: 0 });
  const selected = Math.max(0, options.findIndex(option => option.value === value));
  const rest = options.map((_, index) => index).filter(index => index !== anchorIndex);
  const order = down ? [anchorIndex, ...rest] : [...rest, anchorIndex];
  function begin() { setAnchorIndex(selected); setActive(selected); setOpen(true); }
  function close(focus = false) { returnFocus.current = focus; setOpen(false); }
  function choose(index: number) { if (options[index]) onChange(options[index].value); close(true); }
  function position() {
    const popup = menu.current, box = anchor.current;
    if (popup && box) popup.style.top = `${box.down ? box.top : box.bottom - popup.offsetHeight}px`;
  }
  useLayoutEffect(() => {
    const popup = menu.current;
    if (!popup) return;
    popup.inert = !open || disabled;
    if (!open || disabled) return;
    const button = trigger.current?.querySelector('button');
    if (!button) return;
    const rect = button.getBoundingClientRect(), style = getComputedStyle(button);
    const below = innerHeight - rect.bottom - 12, above = rect.top - 12;
    const unfoldsDown = below >= Math.min(220, (options.length - 1) * (rect.height + 4)) || below >= above;
    anchor.current = { left: rect.left, top: rect.top, bottom: rect.bottom, width: rect.width, height: rect.height, down: unfoldsDown };
    setDown(unfoldsDown);
    popup.style.width = `${rect.width}px`; popup.style.left = `${rect.left}px`;
    popup.style.setProperty('--select-anchor-height', `${rect.height}px`);
    popup.style.setProperty('--select-anchor-padding', style.padding);
    popup.style.setProperty('--select-anchor-font', style.fontSize);
    popup.style.setProperty('--select-anchor-font-family', style.fontFamily);
    popup.style.setProperty('--select-anchor-font-weight', style.fontWeight);
    popup.style.setProperty('--select-anchor-line-height', style.lineHeight);
    popup.style.setProperty('--select-anchor-letter-spacing', style.letterSpacing);
    popup.style.setProperty('--select-anchor-gap', style.gap);
    popup.style.setProperty('--select-anchor-radius', style.borderRadius);
    const shell=popup.querySelector<HTMLElement>('.glass-select-menu');
    shell?.style.setProperty('--glass-core-width', `${rect.width}px`);
    shell?.style.setProperty('--glass-core-height', `${rect.height}px`);
    popup.style.setProperty('--select-list-height', `${Math.min(310, Math.max(rect.height, (unfoldsDown ? below : above) - 4))}px`);
    popup.style.setProperty('--glass-reveal-origin', unfoldsDown ? 'top left' : 'bottom left');
    popup.showPopover(); position(); setPresent(true);
    const toggle = () => { if (!popup.matches(':popover-open')) { setPresent(false); setOpen(false); } };
    const dismiss = (event: Event) => { if (!(event.target instanceof Element && popup.contains(event.target))) close(); };
    const outside = (event: Event) => { if (event.target instanceof Node && !popup.contains(event.target) && !trigger.current?.contains(event.target)) close(); };
    const escape = (event: globalThis.KeyboardEvent) => { if (event.key === 'Escape') { event.preventDefault(); close(true); } };
    popup.addEventListener('toggle', toggle);
    window.addEventListener('resize', dismiss); document.addEventListener('scroll', dismiss, true);
    document.addEventListener('pointerdown', outside, true); document.addEventListener('keydown', escape);
    return () => {
      popup.removeEventListener('toggle', toggle); window.removeEventListener('resize', dismiss); document.removeEventListener('scroll', dismiss, true);
      document.removeEventListener('pointerdown', outside, true); document.removeEventListener('keydown', escape);
    };
  }, [open, disabled, options.length]);
  useLayoutEffect(position, [expanded, down, anchorIndex]);
  useLayoutEffect(() => { if (!present && returnFocus.current) { returnFocus.current = false; trigger.current?.querySelector<HTMLButtonElement>('button')?.focus({ preventScroll: true }); } }, [present]);
  useLayoutEffect(() => () => { const popup = menu.current; if (popup?.matches(':popover-open')) popup.hidePopover(); }, []);
  useLayoutEffect(() => {
    if (open && expanded && active !== anchorIndex) menu.current?.querySelector<HTMLElement>(`[data-option-index="${active}"]`)?.scrollIntoView({ block: 'nearest' });
    if (open && expanded && keyboardNavigation.current) { keyboardNavigation.current = false; menu.current?.querySelector<HTMLElement>(`[data-option-index="${active}"]`)?.focus({ preventScroll: true }); }
  }, [active, open, expanded, anchorIndex]);
  function keydown(event: KeyboardEvent) {
    if (event.key === 'Tab') { close(); return; }
    if (event.key === 'Escape') { event.preventDefault(); close(true); return; }
    if (['Enter', ' '].includes(event.key)) { event.preventDefault(); if (open) choose(active); else begin(); return; }
    if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
      event.preventDefault();
      if (!open) { begin(); return; }
      keyboardNavigation.current = true;
      const position = Math.max(0, order.indexOf(active));
      setActive(order[event.key === 'Home' ? 0 : event.key === 'End' ? order.length - 1 : Math.max(0, Math.min(order.length - 1, position + (event.key === 'ArrowDown' ? 1 : -1)))]);
      return;
    }
    if (event.key.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey) {
      const now = performance.now();
      typeahead.current = { text: (now - typeahead.current.time < 600 ? typeahead.current.text : '') + event.key.toLowerCase(), time: now };
      const match = options.findIndex(option => option.label.toLowerCase().startsWith(typeahead.current.text));
      if (match >= 0) { event.preventDefault(); keyboardNavigation.current = true; if (!open) begin(); setActive(match); }
    }
  }
  const row = (index: number, pinned = false) => <GlassButton key={options[index]?.value} id={`${id}-option-${index}`} className={`glass-select-option${pinned ? ' glass-select-anchor' : ''}`} role="option" aria-selected={options[index]?.value === value} tabIndex={index === active ? 0 : -1} data-option-index={index} data-active={index === active}
    onPointerMove={() => setActive(index)} onPointerDown={event => event.preventDefault()} onClick={() => choose(index)}><span className="select-value">{options[index]?.label}</span><i className={pinned ? 'select-chevron' : 'select-check'} aria-hidden="true" /></GlassButton>;
  const remaining = expanded && <GlassScrollArea viewportClassName="select-options" label={`Scroll ${label} options`}>{rest.map(index => row(index))}</GlassScrollArea>;
  return <span ref={trigger} className="glass-select" data-menu-present={present}>
    <GlassButton className="glass-select-trigger" role="combobox" aria-label={label} aria-describedby={`${id}-value`} aria-expanded={open} aria-haspopup="listbox" aria-controls={`${id}-list`} aria-activedescendant={open ? `${id}-option-${active}` : undefined} disabled={disabled}
      onClick={() => open ? close(true) : begin()} onKeyDown={keydown}>
      <span id={`${id}-value`} className="select-value">{options[selected]?.label}</span><i className="select-chevron" aria-hidden="true" />
    </GlassButton>
    <div ref={menu} {...{ popover: 'manual' }} className="glass-select-popover" data-unfold={down ? 'down' : 'up'} onKeyDown={keydown}>
      <Glass className="glass-select-menu" material="surface" fade={[]} reveal={open && !disabled} revealOriginBox={() => anchor.current}
        onRevealPrepare={show => { setExpanded(show); if (!show) setAnchorIndex(selected); }}
        onRevealCommit={show => { if (!show) { setExpanded(false); setAnchorIndex(selected); } }}
        onRevealEnd={show => { if (show) menu.current?.querySelector<HTMLElement>(`[data-option-index="${active}"]`)?.focus({ preventScroll: true }); else { const popup = menu.current; if (popup?.matches(':popover-open')) popup.hidePopover(); setPresent(false); } }}>
        <div id={`${id}-list`} role="listbox" aria-label={`${label} options`}>
          {down ? <>{row(anchorIndex, true)}{remaining}</> : <>{remaining}{row(anchorIndex, true)}</>}
        </div>
      </Glass>
    </div>
  </span>;
}
