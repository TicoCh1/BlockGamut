import { useEffect, useState } from 'react';
import { foregroundText } from './foregroundText';
import { GlassField } from './Glass';
import { DopplerRange } from './DopplerRange';

type Props = { label: string; value: number; min: number; max: number; step: number; unit: string; disabled?: boolean; onChange: (value: number) => void };

export function ParameterControl({ label, value, min, max, step, unit, disabled = false, onChange }: Props) {
  const [draft, setDraft] = useState(String(value));
  const [editing, setEditing] = useState(false);
  useEffect(() => { if (!editing) setDraft(String(value)); }, [value, editing]);
  function normalize(number: number) {
    const clamped = Math.max(min, Math.min(max, number));
    return Number((min + Math.round((clamped - min) / step) * step).toFixed(6));
  }
  function commit() {
    const parsed = draft.trim() === '' ? NaN : Number(draft);
    const next = Number.isFinite(parsed) ? normalize(parsed) : value;
    setDraft(String(next));
    setEditing(false);
    onChange(next);
  }
  return foregroundText(<div className="range-row parameter-control">
    <div className="parameter-heading"><span>{label}</span><GlassField className="parameter-number"><input type="number" aria-label={`${label} value`} min={min} max={max} step={step} disabled={disabled} value={draft} onFocus={() => setEditing(true)} onChange={e => {
      const text = e.target.value;
      setDraft(text);
      const parsed = text.trim() === '' ? NaN : Number(text);
      if (Number.isFinite(parsed) && parsed >= min && parsed <= max) onChange(normalize(parsed));
    }} onBlur={commit} onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); e.currentTarget.blur(); } }} /><span aria-hidden="true">{unit}</span></GlassField></div>
    <DopplerRange label={label} min={min} max={max} step={step} value={value} disabled={disabled} onChange={onChange} onPreview={next=>setDraft(String(next))} />
  </div>);
}
