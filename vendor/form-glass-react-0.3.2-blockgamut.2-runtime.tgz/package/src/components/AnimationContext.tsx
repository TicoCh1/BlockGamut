import { createContext, useContext, type ReactNode } from 'react';
import { DEFAULT_ANIMATION_SETTINGS, type AnimationSettings } from '../styles/animationSettings';

const Context = createContext<AnimationSettings>(DEFAULT_ANIMATION_SETTINGS);
export function AnimationSettingsProvider({ value, children }: { value: AnimationSettings; children: ReactNode }) {
  return <Context.Provider value={value}>{children}</Context.Provider>;
}
export function useAnimationSettings() { return useContext(Context); }
