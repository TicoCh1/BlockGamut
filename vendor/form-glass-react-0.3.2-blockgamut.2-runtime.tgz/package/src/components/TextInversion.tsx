import {getGlassRoot} from '../styles/glassRoot';
import { useLayoutEffect } from 'react';
import { nativeScrollTimeline, nativeViewTimeline, scrollFadeKeyframes } from '../styles/scrollFade';
import type { GlassFadeCurve } from '../styles/glassFade';
import { revealContentFrames } from '../styles/revealTimeline';

const typography = ['font-family', 'font-size', 'font-weight', 'font-style', 'font-variant', 'line-height', 'letter-spacing', 'word-spacing', 'text-transform', 'text-align', 'text-indent', 'white-space', 'overflow-x', 'overflow-y', 'text-overflow', 'padding-top', 'padding-right', 'padding-bottom', 'padding-left', 'border-top-width', 'border-right-width', 'border-bottom-width', 'border-left-width', 'box-sizing'] as const;

/** Blend glyph paint after the isolated glass groups have been composited.
 * CSS does the pixel inversion. No screenshot/readback or backdrop cache. */
export function TextInversion({ active, revision, distance, mid, curve }: { active: boolean; revision: string; distance: number; mid: number; curve: GlassFadeCurve }) {
  useLayoutEffect(() => {
    if (!active) return;
    const root = getGlassRoot();
    const layer = document.createElement('div');
    layer.className = 'inverse-glyph-layer'; layer.setAttribute('aria-hidden', 'true');
    document.body.append(layer);
    const modalLayer = layer.cloneNode(false) as HTMLElement;
    modalLayer.setAttribute('popover', 'manual'); document.body.append(modalLayer);
    document.documentElement.dataset.inverseGlyphs = '';
    let frame = 0;
    const clones = new Map<HTMLElement, HTMLElement>();
    const ScrollTimeline = nativeScrollTimeline(), ViewTimeline = nativeViewTimeline();
    const groups = new Map<HTMLElement, { clip: HTMLElement; content: HTMLElement; animation?: Animation; range: number }>();
    const fadeAnimations = new Map<HTMLElement, { animation: Animation; signature: string }>();
    const revealAnimations=new Map<HTMLElement,Animation>();
    const update = () => {
      frame = 0;
      const modal = root.querySelector('dialog[open], [popover]:popover-open');
      if (modal && !modalLayer.matches(':popover-open')) modalLayer.showPopover();
      else if (!modal && modalLayer.matches(':popover-open')) modalLayer.hidePopover();
      const visible = new Set<HTMLElement>();
      const occluders = [...root.querySelectorAll('.material-dock, .backdrop-credit, .showcase-drag-card, .contact-drag-handle')].filter(element=>!element.closest('[data-glass-transition-copy]')).map(element => ({ element, rect: element.getBoundingClientRect() }));
      const dialogOpen = Boolean(root.querySelector('dialog[open]'));
      const clips = new Map<HTMLElement, { x: boolean; y: boolean; rect: DOMRect; width: number; height: number }>();
      root.querySelectorAll<HTMLElement>('glass-text, [data-live-wordmark], [data-instrument-display], input:not([type="range"]):not([type="checkbox"]), select').forEach(source => {
        const reveal=source.closest<HTMLElement>('[data-glass-reveal-phase],[data-glass-content-phase]');
        if(reveal&&['preparing','moving','settling'].includes(reveal.dataset.glassRevealPhase??reveal.dataset.glassContentPhase!))return;
        const viewport = ScrollTimeline && ViewTimeline && !source.closest('[popover]') ? source.closest<HTMLElement>('.glass-scroll-viewport') : null;
        const rect = source.getBoundingClientRect();
        if (!rect.width || !rect.height || !viewport && (rect.bottom < 0 || rect.top > innerHeight || rect.right < 0 || rect.left > innerWidth)) return;
        const computed = getComputedStyle(source);
        if (computed.visibility === 'hidden' || computed.display === 'none') return;
        const disabledParent = source.closest('button:disabled');
        const inheritedOpacity = disabledParent ? Number(getComputedStyle(disabledParent).opacity) : 1;
        const paintOpacity = Number(source.dataset.scrollFadeOpacity ?? computed.opacity) * inheritedOpacity;
        let clone = clones.get(source);
        if (!clone) {
          clone = source.cloneNode(true) as HTMLElement;
          clone.removeAttribute('id'); clone.removeAttribute('aria-label'); clone.removeAttribute('data-foreground-fade');
          clone.removeAttribute('data-glass-text'); clone.removeAttribute('name'); clone.removeAttribute('class');
          clone.tabIndex = -1; clone.style.cssText = '';
          clone.className = 'inverse-glyph'; layer.append(clone); clones.set(source, clone);
          if(source.hasAttribute('data-instrument-display'))clone.classList.add('instrument-number');
        }
        let destination = modal?.contains(source) ? modalLayer : layer;
        let viewportRect: DOMRect | undefined;
        if (viewport) {
          viewportRect = viewport.getBoundingClientRect();
          let group = groups.get(viewport);
          if (!group) {
            const clip = document.createElement('div'), content = document.createElement('div');
            clip.className = 'inverse-scroll-clip'; content.className = 'inverse-scroll-content';
            clip.append(content); destination.append(clip);
            group = { clip, content, range: -1 }; groups.set(viewport, group);
          }
          Object.assign(group.clip.style, { left: `${viewportRect.left}px`, top: `${viewportRect.top}px`, width: `${viewport.clientWidth}px`, height: `${viewport.clientHeight}px` });
          const range = Math.max(0, viewport.scrollHeight - viewport.clientHeight);
          if (group.range !== range) {
            group.animation?.cancel(); group.range = range;
            if (range > 0) group.animation = group.content.animate({ transform: ['translateY(0px)', `translateY(${-range}px)`] }, { timeline: new ScrollTimeline!({ source: viewport, axis: 'block' }), fill: 'both' });
          }
          destination = group.content;
        }
        if (clone.parentElement !== destination) destination.append(clone);
        if (source instanceof HTMLInputElement && clone instanceof HTMLInputElement) clone.value = source.value;
        else if (source instanceof HTMLSelectElement && clone instanceof HTMLSelectElement) { if (clone.innerHTML !== source.innerHTML) clone.innerHTML = source.innerHTML; clone.selectedIndex = source.selectedIndex; }
        else if(source.hasAttribute('data-live-wordmark')) copyWordmark(source,clone);
        else if(source.hasAttribute('data-instrument-display')) {
          if(clone.innerHTML!==source.innerHTML) {
            clone.innerHTML=source.innerHTML;
            const sourceAnimations=source.getAnimations({subtree:true}),copies=clone.getAnimations({subtree:true});
            copies.forEach((animation,i)=>{if(sourceAnimations[i])animation.currentTime=sourceAnimations[i].currentTime;});
          }
        } else if (clone.textContent !== source.textContent) clone.textContent = source.textContent;
        typography.forEach(property => { const value = computed.getPropertyValue(property); if (clone!.style.getPropertyValue(property) !== value) clone!.style.setProperty(property, value); });
        Object.assign(clone.style, { left: `${rect.left - (viewportRect?.left ?? 0)}px`, top: `${rect.top - (viewportRect?.top ?? 0) + (viewport?.scrollTop ?? 0)}px`, width: `${rect.width}px`, height: `${rect.height}px`, opacity: String(paintOpacity) });
        if (viewport && source.dataset.scrollFadeOpacity !== undefined) {
          const bounds = { top: rect.top - viewportRect!.top + viewport.scrollTop, range: viewport.scrollHeight - viewport.clientHeight };
          const signature = `${viewport.clientHeight}/${rect.height}/${paintOpacity}/${bounds.top.toFixed(3)}/${bounds.range}`;
          if (fadeAnimations.get(source)?.signature !== signature) {
            fadeAnimations.get(source)?.animation.cancel();
            const animation = clone.animate(scrollFadeKeyframes(viewport.clientHeight, rect.height, distance, mid, curve, paintOpacity, bounds), { timeline: new ViewTimeline!({ subject: source, axis: 'block', inset: '0px' }), fill: 'both' });
            fadeAnimations.set(source, { animation, signature });
          }
        } else { fadeAnimations.get(source)?.animation.cancel(); fadeAnimations.delete(source); }
        // The same projected mask fades the inverse glyph, after difference
        // blending; no parent holding a backdrop-filter is masked.
        ['mask-image', 'mask-size', 'mask-position', 'mask-repeat', 'mask-composite', 'mask-mode'].forEach(property => clone!.style.setProperty(property, computed.getPropertyValue(property)));
        let left = rect.left, top = rect.top, right = rect.right, bottom = rect.bottom;
        // Respect real ancestor scroll/overflow clips; the overlay must never
        // resurrect content cropped out of the DOM control.
        let ancestor = source.parentElement;
        while (ancestor && ancestor !== root) {
          if (!clips.has(ancestor)) {
            const style = getComputedStyle(ancestor);
            clips.set(ancestor, { x: ['hidden', 'clip', 'auto', 'scroll'].includes(style.overflowX), y: ['hidden', 'clip', 'auto', 'scroll'].includes(style.overflowY), rect: ancestor.getBoundingClientRect(), width: ancestor.clientWidth, height: ancestor.clientHeight });
          }
          const clip = clips.get(ancestor)!;
          if (ancestor !== viewport) {
            if (clip.x) { left = Math.max(left, clip.rect.left); right = Math.min(right, clip.rect.left + clip.width); }
            if (clip.y) { top = Math.max(top, clip.rect.top); bottom = Math.min(bottom, clip.rect.top + clip.height); }
          }
          if (ancestor.hasAttribute('popover')) break;
          ancestor = ancestor.parentElement;
        }
        let pieces = [[left, top, right, bottom]];
        // The fixed parameter panel is above the page's foreground. Keep
        // page glyphs out of its area, instead of drawing them over its UI.
        if (!source.closest('.material-tools, .backdrop-credit, [popover]') && !dialogOpen) for (const {element,rect:cover} of occluders) {
          if (element.contains(source)) continue;
          pieces = pieces.flatMap(([l, t, r, b]) => {
            if (cover.left >= r || cover.right <= l || cover.top >= b || cover.bottom <= t) return [[l, t, r, b]];
            const y0 = Math.max(t, cover.top), y1 = Math.min(b, cover.bottom);
            return [[l, t, r, y0], [l, y1, r, b], [l, y0, Math.min(r, cover.left), y1], [Math.max(l, cover.right), y0, r, y1]];
          });
        }
        const paths = pieces.filter(([l, t, r, b]) => r > l && b > t).map(([l, t, r, b]) => `M${l - rect.left} ${t - rect.top}H${r - rect.left}V${b - rect.top}H${l - rect.left}Z`).join(' ');
        clone.style.clipPath = `path("${paths || 'M0 0H0V0Z'}")`;
        visible.add(source);
      });
      clones.forEach((clone, source) => { if (!visible.has(source)) { clone.remove(); clones.delete(source); fadeAnimations.get(source)?.animation.cancel(); fadeAnimations.delete(source);revealAnimations.get(source)?.cancel();revealAnimations.delete(source); } });
      groups.forEach((group, viewport) => { if (!viewport.isConnected) { group.animation?.cancel(); group.clip.remove(); groups.delete(viewport); } });
    };
    // cloneNode never copies a canvas bitmap. Copy on initial layout and on
    // each wordmark paint, without queuing a second frame or DOM-wide update.
    const copyWordmark = (source:HTMLElement,clone:HTMLElement) => {
      const original=source.querySelector('canvas'),copy=clone.querySelector('canvas');
      if(!original||!copy)return;
      if(copy.width!==original.width)copy.width=original.width;
      if(copy.height!==original.height)copy.height=original.height;
      const ctx=copy.getContext('2d');
      ctx?.clearRect(0,0,copy.width,copy.height);ctx?.drawImage(original,0,0);
      clone.dataset.paintCount=source.dataset.paintCount;
      clone.dataset.paintColor=source.dataset.paintColor;
    };
    const wordmarkPaint = (event:Event) => {
      if(!(event.target instanceof HTMLElement))return;
      const clone=clones.get(event.target);
      if(clone)copyWordmark(event.target,clone);
    };
    const schedule = () => { if (!frame) frame = requestAnimationFrame(update); };
    const revealPhase=(event:Event)=>{
      if(!(event instanceof CustomEvent)||!(event.target instanceof HTMLElement))return;
      const host=event.target,{phase,duration,startTime,blurLimit=64,contentTiming}=event.detail;
      cancelAnimationFrame(frame);update();
      clones.forEach((clone,source)=>{
        if(!host.contains(source))return;
        revealAnimations.get(source)?.cancel();revealAnimations.delete(source);
        if(phase!=='hiding'&&phase!=='showing')return;
        const base=clone.style.opacity===''?1:Number(clone.style.opacity);
        const animation=clone.animate(revealContentFrames(phase==='hiding'?base:0,phase==='hiding'?0:base,phase==='hiding'?0:blurLimit,phase==='hiding'?blurLimit:0,contentTiming),{duration,easing:'linear',fill:'both'});
        animation.startTime=startTime;revealAnimations.set(source,animation);
        animation.onfinish=()=>{animation.cancel();revealAnimations.delete(source);};
      });
    };
    const drag = (event: PointerEvent) => { if (event.buttons && event.target instanceof Element && event.target.closest('.showcase-drag-card')) schedule(); };
    const keydown = (event: KeyboardEvent) => {
      if (ScrollTimeline && ViewTimeline && ['ArrowUp', 'ArrowDown', 'PageUp', 'PageDown', 'Home', 'End'].includes(event.key) && event.target instanceof Element && event.target.closest('.glass-scroll-viewport, .glass-scroll-rail')) return;
      schedule();
    };
    // Leaf masks change after parameter and scroll geometry updates. Writes
    // to this separate layer are outside the observed React tree.
    const observer = new MutationObserver(records => {
      if (records.some(record => record.attributeName !== 'style' || !(record.target instanceof Element && record.target.matches('.glass-scroll-thumb')))) schedule();
    });
    observer.observe(root, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['style', 'class', 'open', 'data-foreground-fade'] });
    const resize = new ResizeObserver(schedule); resize.observe(root);
    const scroll = (event: Event) => {
      if (ScrollTimeline && ViewTimeline && event.target instanceof Element && event.target.matches('.glass-scroll-viewport')) return;
      schedule();
    };
    window.addEventListener('resize', schedule); document.addEventListener('scroll', scroll, true);
    document.addEventListener('input', schedule); document.addEventListener('change', schedule);
    document.addEventListener('toggle', schedule, true);
    document.addEventListener('wordmarkpaint',wordmarkPaint);
    document.addEventListener('glassrevealphase',revealPhase);
    document.addEventListener('pointermove', drag, { passive: true }); document.addEventListener('keydown', keydown);
    update();
    return () => {
      cancelAnimationFrame(frame); observer.disconnect(); resize.disconnect(); layer.remove(); modalLayer.remove();
      delete document.documentElement.dataset.inverseGlyphs;
      window.removeEventListener('resize', schedule); document.removeEventListener('scroll', scroll, true);
      groups.forEach(group => group.animation?.cancel()); fadeAnimations.forEach(({ animation }) => animation.cancel());
      revealAnimations.forEach(animation=>animation.cancel());document.removeEventListener('glassrevealphase',revealPhase);
      document.removeEventListener('input', schedule); document.removeEventListener('change', schedule);
      document.removeEventListener('toggle', schedule, true);
      document.removeEventListener('wordmarkpaint',wordmarkPaint);
      document.removeEventListener('pointermove', drag); document.removeEventListener('keydown', keydown);
    };
  }, [active, revision, distance, mid, curve]);
  return null;
}
