import {useLayoutEffect,useRef,useState} from 'react';
import {DopplerRange} from './DopplerRange';
import {RANGE_PROFILE} from '../styles/rangeShape';

/** Two instances of the original FORM thumb share one rail and value domain. */
export function DopplerRangePair({labels,value,min,max,step,disabled,onChange,onPreview,formatValue}:{labels:[string,string];value:[number,number];min:number;max:number;step:number;disabled?:boolean;formatValue?:(value:number)=>string;onChange:(value:[number,number])=>void;onPreview?:(value:[number,number])=>void}){
 const host=useRef<HTMLSpanElement>(null),[width,setWidth]=useState(200),[draft,setDraft]=useState(value),latest=useRef(value);
 useLayoutEffect(()=>{latest.current=value;setDraft(value);},[value[0],value[1]]);
 useLayoutEffect(()=>{const node=host.current!,observer=new ResizeObserver(entries=>{const w=entries[0].contentRect.width;if(w>0&&!node.closest('[data-glass-reveal-phase="moving"]'))setWidth(w);});observer.observe(node);return()=>observer.disconnect();},[]);
 const centres=draft.map(v=>6+(width-12)*(v-min)/(max-min)),split=(centres[0]+centres[1])/2/width*100,gap=RANGE_PROFILE.gap;
 const preview=(index:number,v:number)=>{const next:[number,number]=[...latest.current];next[index]=v;latest.current=next;setDraft(next);onPreview?.(next);};
 const commit=(index:number,v:number)=>{preview(index,v);onChange(latest.current);};
 const segments=[[1,centres[0]-gap],[centres[0]+gap,centres[1]-gap],[centres[1]+gap,width-1]].filter(([a,b])=>b>a);
 return <div className="range-field range-no-glass"><span className="doppler-range doppler-range-pair" ref={host}>
  <svg className="doppler-track" viewBox={`0 0 ${width} 26`} preserveAspectRatio="none" aria-hidden="true" style={{'--range-stroke':RANGE_PROFILE.stroke} as React.CSSProperties}><path className="doppler-line" d={segments.map(([a,b])=>`M${a} 13H${b}`).join('')}/></svg>
  {[0,1].map(index=><div className="doppler-pair-thumb" key={index}><DopplerRange label={labels[index]} value={draft[index]} min={min} max={max} step={step} disabled={disabled} rail={false} valueText={formatValue?.(draft[index])} limits={index===0?[min,draft[1]]:[draft[0],max]} clip={index===0?[0,split]:[split,100]} onPreview={v=>preview(index,v)} onChange={v=>commit(index,v)}/></div>)}
 </span></div>;
}
