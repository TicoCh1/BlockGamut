import {getGlassRoot} from '../styles/glassRoot';
import { useLayoutEffect } from 'react';
import { featherMask } from '../styles/featherMask';
import type { GlassFadeCurve } from '../styles/glassFade';
import { nativeViewTimeline, scrollFadeKeyframes } from '../styles/scrollFade';
import {beginGlassMeasure} from '../styles/performanceProbe';
import {insideOpaqueGlass} from '../styles/opaqueInterior';

type Props = { active: boolean; distance: number; mid: number; curve: GlassFadeCurve };
type Mask = { image: string; rect: DOMRect };
const properties = ['--foreground-mask', '--foreground-size', '--foreground-position'];

/** Project the existing alpha field onto individual paint targets. Never mask
 * an ancestor of a backdrop filter: that would cut off its backdrop sampling. */
export function ForegroundFade({ active, distance, mid, curve }: Props) {
  useLayoutEffect(() => {
    if (!active || distance <= 0) return;
    let frame = 0;
    const ViewTimeline = nativeViewTimeline();
    const animations = new Map<HTMLElement, { animation: Animation; signature: string }>();
    const touched = new Set<HTMLElement>();
    const clear = (element: HTMLElement) => {
      delete element.dataset.foregroundFade;
      properties.forEach(property => element.style.removeProperty(property));
    };
    const update = () => {
      const finish=beginGlassMeasure('foregroundFade');
      frame = 0;
      const masks = new Map<HTMLElement, Mask | null>();
      const rects=new Map<HTMLElement,DOMRect>(),interiors=new Map<HTMLElement,{rect:DOMRect;edges:string[];radius:number}>();
      const rectOf=(node:HTMLElement)=>{let rect=rects.get(node);if(!rect){rect=node.getBoundingClientRect();rects.set(node,rect);}return rect;};
      const opaque=(node:HTMLElement,paint:DOMRect)=>{
        let core=interiors.get(node);
        if(!core){core={rect:rectOf(node),edges:(node.dataset.glassFade??'').split(' '),radius:parseFloat(getComputedStyle(node).getPropertyValue('--glass-radius'))||0};interiors.set(node,core);}
        return insideOpaqueGlass(paint,core.rect,core.edges,core.radius,mid);
      };
      const hostMask = (host: HTMLElement, horizontal = false, paint?: DOMRect): Mask | null => {
        if (horizontal) {
          const edges = (host.dataset.glassFade ?? '').split(' ').filter(e => e === 'left' || e === 'right');
          if (!edges.length) return null;
          const rect = host.getBoundingClientRect();
          const height = paint?.height ?? rect.height;
          const mask = featherMask({ width: rect.width, height, radius: 0, edges, distance, mid, blur: 0, curve });
          return { image: mask.url, rect: new DOMRect(rect.left - mask.inset[3], (paint?.top ?? rect.top) - mask.inset[0], rect.width + mask.inset[1] + mask.inset[3], height + mask.inset[0] + mask.inset[2]) };
        }
        if (masks.has(host)) return masks.get(host)!;
        const renderer = host.querySelector<HTMLElement>(':scope > .glass-renderer[data-feather-mask]');
        const image = renderer?.style.getPropertyValue('--glass-feather-mask');
        const mask = renderer && image ? { image, rect: renderer.getBoundingClientRect() } : null;
        masks.set(host, mask); return mask;
      };
      const scrollMasks = new Map<HTMLElement, Mask | null>();
      if (!ViewTimeline) document.querySelectorAll<HTMLElement>('.glass-scroll-viewport').forEach(viewport => {
        const rect = viewport.getBoundingClientRect();
        const edges = [viewport.scrollTop > 1 ? 'top' : '', viewport.scrollTop + viewport.clientHeight < viewport.scrollHeight - 1 ? 'bottom' : ''].filter(Boolean);
        // Crop boundaries need an inward feather: no content may remain opaque
        // right at a hard scroll clip. A negative mid contracts it further.
        const mask = edges.length ? featherMask({ width: viewport.clientWidth, height: viewport.clientHeight, radius: 0, edges, distance, mid: Math.min(mid, 0) - distance, blur: 0, curve }) : null;
        scrollMasks.set(viewport, mask ? { image: mask.url, rect: new DOMRect(rect.left - mask.inset[3], rect.top - mask.inset[0], viewport.clientWidth + mask.inset[1] + mask.inset[3], viewport.clientHeight + mask.inset[0] + mask.inset[2]) } : null);
      });
      const current = new Set<HTMLElement>();
      const activeAnimations = new Set<HTMLElement>();
      const writes:(()=>void)[]=[];
      const targets = document.querySelectorAll<HTMLElement>('glass-text, [data-instrument-display], .glass-hover-edge, input, select, [data-glass] i:not(.scroll-grip), [data-glass] > .glass-renderer > .glass-blur-layer:last-child, [data-glass] > .glass-renderer[data-separate-fades] > .glass-blur-layer:nth-child(6), [data-glass] > .glass-renderer[data-separate-fades] > .glass-blur-layer:nth-child(7)');
      targets.forEach(target => {
        if(target.closest('[data-glass-transition-copy]'))return;
        const revealing=target.closest<HTMLElement>('[data-glass-reveal-phase],[data-glass-content-phase]');
        if(revealing&&['preparing','moving'].includes(revealing.dataset.glassRevealPhase??revealing.dataset.glassContentPhase!)){
          // Hidden paint needs no screen-space projection while its shell
          // scales. Keep old recipes and project once into the final layout.
          if(touched.has(target))current.add(target);
          if(animations.has(target))activeAnimations.add(target);
          return;
        }
        const viewport = target.closest('[popover]') ? null : target.closest<HTMLElement>('.glass-scroll-viewport');
        if (ViewTimeline && viewport) {
          // View timelines measure the untransformed principal box. A rotated
          // chevron's bounding rect is taller than the box that drives it.
          const height = target.matches('i')?parseFloat(getComputedStyle(target).height)||rectOf(target).height:rectOf(target).height;
          const bounds = { top: rectOf(target).top - rectOf(viewport).top + viewport.scrollTop, range: viewport.scrollHeight - viewport.clientHeight };
          const old = animations.get(target);
          const base = target.dataset.scrollFadeOpacity ?? getComputedStyle(target).opacity;
          const signature = `${viewport.clientHeight}/${height}/${base}/${bounds.top.toFixed(3)}/${bounds.range}`;
          if (height > 0 && old?.signature !== signature) {
            old?.animation.cancel();
            target.dataset.scrollFadeOpacity = base;
            const animation = target.animate(scrollFadeKeyframes(viewport.clientHeight, height, distance, mid, curve, Number(base), bounds), { timeline: new ViewTimeline({ subject: target, axis: 'block', inset: '0px' }), fill: 'both' });
            animation.id = 'foreground-scroll-fade';
            animations.set(target, { animation, signature });
          }
          activeAnimations.add(target);
        }
        const list: Mask[] = [];
        const isLayer = target.classList.contains('glass-blur-layer');
        const ownHost = isLayer ? target.parentElement?.parentElement : null;
        if (ownHost) {
          const channel = target.style.getPropertyValue('--glass-channel-mask');
          const own = channel ? { image: channel, rect: target.getBoundingClientRect() } : hostMask(ownHost);
          if (own) list.push(own);
        }
        let ancestor = ownHost?.parentElement ?? target.parentElement;
        while (ancestor) {
          // Solid ancestors have no feather image to project. Skip them before
          // reading the target rect or computed radius; inspectors contain many
          // such secondary controls and these reads used to flush their layout.
          if (ancestor.hasAttribute('data-glass')&&ancestor.dataset.glassFade&&!opaque(ancestor,rectOf(target))) { const mask = hostMask(ancestor, Boolean(ViewTimeline && viewport && !viewport.contains(ancestor)), rectOf(target)); if (mask) list.push(mask); }
          const scrollMask = scrollMasks.get(ancestor); if (scrollMask) list.push(scrollMask);
          if (ancestor.hasAttribute('popover')) break;
          ancestor = ancestor.parentElement;
        }
        // A standalone material already owns its mask. Only decorate layers
        // when there is an additional ancestor/viewport mask to intersect.
        if (!list.length || (isLayer && ownHost && list.length === Number(Boolean(hostMask(ownHost))))) return;
        const rect = rectOf(target);
        if (!rect.width || !rect.height) return;
        const values = [list.map(m => m.image).join(', '), list.map(m => `${m.rect.width}px ${m.rect.height}px`).join(', '), list.map(m => `${m.rect.left - rect.left}px ${m.rect.top - rect.top}px`).join(', ')];
        const changed=properties.filter((property,index)=>target.style.getPropertyValue(property)!==values[index]);
        if(!target.hasAttribute('data-foreground-fade')||changed.length)writes.push(()=>{
          target.dataset.foregroundFade='';
          changed.forEach(property=>target.style.setProperty(property,values[properties.indexOf(property)]));
        });
        current.add(target); touched.add(target);
      });
      // Read all geometry before changing masks. Interleaving these writes
      // with the next glyph's bounding-box read repeatedly flushes styles.
      writes.forEach(write=>write());
      touched.forEach(element => { if (!current.has(element)) { clear(element); touched.delete(element); } });
      animations.forEach(({ animation }, element) => {
        if (!activeAnimations.has(element)) { animation.cancel(); delete element.dataset.scrollFadeOpacity; animations.delete(element); }
      });
      finish?.();
    };
    const schedule = () => { if (!frame) frame = requestAnimationFrame(update); };
    const revealPhase=(event:Event)=>{if(event instanceof CustomEvent&&['settling','showing','idle'].includes(event.detail.phase))schedule();};
    const drag = (event: PointerEvent) => { if (event.buttons && event.target instanceof Element && event.target.closest('.showcase-drag-card')) schedule(); };
    const keydown = (event: KeyboardEvent) => {
      if (ViewTimeline && ['ArrowUp', 'ArrowDown', 'PageUp', 'PageDown', 'Home', 'End'].includes(event.key) && event.target instanceof Element && event.target.closest('.glass-scroll-viewport, .glass-scroll-rail')) return;
      schedule();
    };
    const observer = new MutationObserver(records => {
      if (records.some(record => record.attributeName !== 'style'&&!(record.target instanceof Element&&record.target.closest('[data-glass-transition-copy]')))) schedule();
    });
    observer.observe(getGlassRoot(), { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['data-glass-fade', 'data-feather-mask', 'style'] });
    const resize = new ResizeObserver(entries=>{
      // Foreground layout is suspended during shell motion. Project once at
      // the final layout, rather than rescanning the page on each resize.
      if(entries.some(entry=>!entry.target.closest('[data-glass-reveal-phase="preparing"],[data-glass-reveal-phase="moving"]')))schedule();
    });
    document.querySelectorAll('[data-glass], .glass-scroll-viewport, .glass-scroll-body').forEach(element => resize.observe(element));
    window.addEventListener('resize', schedule);
    const scroll = (event: Event) => {
      if (ViewTimeline && event.target instanceof Element && event.target.matches('.glass-scroll-viewport')) return;
      if (!ViewTimeline) { cancelAnimationFrame(frame); update(); }
      else schedule();
    };
    document.addEventListener('scroll', scroll, true);
    // Pointer/keyboard movement can translate the specimen without resizing.
    document.addEventListener('pointermove', drag, { passive: true });
    document.addEventListener('keydown', keydown);
    document.addEventListener('glassrevealphase',revealPhase);
    update();
    return () => {
      cancelAnimationFrame(frame); observer.disconnect(); resize.disconnect();
      window.removeEventListener('resize', schedule); document.removeEventListener('scroll', scroll, true);
      document.removeEventListener('pointermove', drag); document.removeEventListener('keydown', keydown);
      document.removeEventListener('glassrevealphase',revealPhase);
      touched.forEach(clear);
      animations.forEach(({ animation }, element) => { animation.cancel(); delete element.dataset.scrollFadeOpacity; });
    };
  }, [active, distance, mid, curve]);
  return null;
}
