import { createContext, useContext, type AnchorHTMLAttributes, type ButtonHTMLAttributes, type HTMLAttributes, type ReactNode, type Ref } from 'react';
import { GlassMaterial } from '../styles/GlassMaterial';
import { GlassRefraction } from './GlassRefraction';
import { GlassFeatherMask } from './GlassFeatherMask';
import { GlassReveal } from './GlassReveal';
import type {RevealBox} from '../styles/revealTimeline';
import { glassSurface, type GlassGeometry } from '../styles/glass';

import { foregroundText } from './foregroundText';

const InsideGlass = createContext(false);

/** Library actions retain the control recipe even outside a visual panel. */
export function GlassControlScope({children}:{children:ReactNode}) {
  return <InsideGlass.Provider value={true}>{children}</InsideGlass.Provider>;
}

export function Glass({ children, className = '', shape = 'rectangle', fade, material = 'surface', reveal = false, onRevealPrepare, onRevealCommit, onRevealEnd, revealOriginBox, surfaceRef, ...props }: HTMLAttributes<HTMLDivElement> & GlassGeometry & { children?: ReactNode; surfaceRef?:Ref<HTMLDivElement>;reveal?:boolean;onRevealPrepare?:(open:boolean)=>void;onRevealCommit?:(open:boolean)=>void;onRevealEnd?:(open:boolean)=>void;revealOriginBox?:()=>RevealBox|null }) {
  return <div {...props} ref={surfaceRef} className={`glass ${className}`} {...glassSurface({ shape, fade, material })}><GlassMaterial /><GlassFeatherMask geometryKey={`${shape}/${fade?.join(' ') ?? 'all'}`} /><GlassRefraction edges={fade} /><GlassReveal active={reveal} onPrepare={onRevealPrepare} onCommit={onRevealCommit} onEnd={onRevealEnd} originBox={revealOriginBox}/><InsideGlass.Provider value={true}>{foregroundText(children)}</InsideGlass.Provider></div>;
}

// Match Semantic Map's hierarchy: standalone surfaces use the surface recipe;
// controls inside a glass panel use its compensated control recipe, with no fade.
function useControlGeometry({ shape = 'rectangle', fade, material }: GlassGeometry): GlassGeometry {
  const nested = useContext(InsideGlass);
  return { shape, material: material ?? (nested ? 'control' : 'surface'), fade: fade ?? (nested ? [] : undefined) };
}

export function GlassButton({ children, className = '', shape, fade, material, type = 'button', ...props }: ButtonHTMLAttributes<HTMLButtonElement> & GlassGeometry) {
  const geometry = useControlGeometry({ shape, fade, material });
  return <button {...props} type={type} className={`glass glass-button ${className}`} {...glassSurface(geometry)}><GlassMaterial /><GlassFeatherMask geometryKey={`${geometry.shape}/${geometry.fade?.join(' ') ?? 'all'}`} /><GlassRefraction control={geometry.material === 'control'} edges={geometry.fade} /><span className="glass-hover-edge" aria-hidden="true" />{foregroundText(children)}</button>;
}

export function GlassLink({ children, className = '', shape, fade, material, ...props }: AnchorHTMLAttributes<HTMLAnchorElement> & GlassGeometry) {
  const geometry = useControlGeometry({ shape, fade, material });
  return <a {...props} className={`glass glass-link ${className}`} {...glassSurface(geometry)}><GlassMaterial /><GlassFeatherMask geometryKey={`${geometry.shape}/${geometry.fade?.join(' ') ?? 'all'}`} /><GlassRefraction control={geometry.material === 'control'} edges={geometry.fade} /><span className="glass-hover-edge" aria-hidden="true" />{foregroundText(children)}</a>;
}

export function GlassField({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={`glass-field ${className ?? ''}`} {...glassSurface({ material: 'control', fade: [] })}><GlassMaterial /><GlassRefraction control edges={[]} />{foregroundText(children)}</div>;
}
