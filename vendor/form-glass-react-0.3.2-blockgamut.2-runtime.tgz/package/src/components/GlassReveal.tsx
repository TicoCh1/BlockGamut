import {useLayoutEffect,useRef} from 'react';
import {flushSync} from 'react-dom';
import {fitRevealSeed,revealGeometryFrames,revealProgress,type RevealBox} from '../styles/revealTimeline';
import {useAnimationSettings} from './AnimationContext';
import {foregroundRoots,foregroundMotion,announcePhase,nextPaint} from './foregroundMotion';
import {glassLayoutBox} from '../styles/glassLayout';
import {beginGlassMeasure} from '../styles/performanceProbe';
import {beginNineSlice,nineSliceMinimum} from '../styles/nineSlice';
import {revealLayoutPeers} from '../styles/revealPeers';

export function GlassReveal({active,onPrepare,onCommit,onEnd,originBox}:{active:boolean;onPrepare?:(open:boolean)=>void;onCommit?:(open:boolean)=>void;onEnd?:(open:boolean)=>void;originBox?:()=>RevealBox|null}){
  const settings=useAnimationSettings(),latest=useRef({settings,onPrepare,onCommit,onEnd,originBox});latest.current={settings,onPrepare,onCommit,onEnd,originBox};
  const anchor=useRef<HTMLSpanElement>(null),wasActive=useRef(false),requested=useRef(active),progress=useRef(0);
  const compact=useRef<RevealBox|null>(null),expanded=useRef<RevealBox|null>(null),interrupted=useRef<RevealBox|null>(null);requested.current=active;
  const retired=useRef(false);
  const mountedOpen=useRef(active),handoff=useRef<ReturnType<typeof foregroundMotion>>();
  useLayoutEffect(()=>{
    const host=anchor.current?.parentElement,previous=wasActive.current;wasActive.current=active;
    if(!host||!active&&!previous)return;
    const config=latest.current.settings,from=progress.current,target=active?1:0,duration=config.values[active?'open':'close'];
    const abort=new AbortController(),signal=abort.signal;
    let motion:Animation|undefined,paint:ReturnType<typeof foregroundMotion>|undefined,stopNine:()=>void=()=>{},completed=false;
    const popover=host.closest<HTMLElement>('.glass-select-popover'),dialog=host.closest<HTMLDialogElement>('dialog');
    const entering=active&&from===0&&Boolean(dialog||popover||mountedOpen.current);
    const releaseHandoff=()=>{handoff.current?.cancel();handoff.current=undefined;};
    const original={width:host.style.width,height:host.style.height,padding:host.style.padding,minWidth:host.style.minWidth,minHeight:host.style.minHeight,transform:host.style.transform,dialogHeight:dialog?.style.height??''};
    const restore=()=>{Object.assign(host.style,{width:original.width,height:original.height,padding:original.padding,minWidth:original.minWidth,minHeight:original.minHeight,transform:original.transform});if(dialog)dialog.style.height=original.dialogHeight;};
    const focusBefore=document.activeElement instanceof HTMLElement&&host.contains(document.activeElement)?document.activeElement:null;
    const savedInert=host.inert;host.inert=true;
    // Prevent a newly mounted popup's final contents flashing before its seed.
    host.dataset.glassRevealPhase=retired.current||entering?'preparing':'hiding';
    if(interrupted.current){const box=interrupted.current;host.style.width=`${box.width}px`;host.style.height=`${box.height}px`;const rect=host.getBoundingClientRect();host.style.transform=`translate(${(box.left??rect.left)-rect.left}px,${(box.top??rect.top)-rect.top}px)`;}
    const peers:HTMLElement[]=[];
    const peerMotions:Animation[]=[],peerRestores:(()=>void)[]=[],peerNine:(()=>void)[]=[];
    const clear=()=>{for(const node of [host,...peers]){delete node.dataset.glassRevealPhase;delete node.dataset.glassRevealing;node.dispatchEvent(new CustomEvent('glassrevealphase',{bubbles:true,detail:{phase:'idle'}}));}host.inert=savedInert;};
    const restoreFocus=()=>{
      if(!dialog&&!popover&&focusBefore&&document.activeElement===document.body){
        const focus=focusBefore.isConnected&&focusBefore.getClientRects().length?focusBefore:host.querySelector<HTMLElement>('button');
        focus?.focus({preventScroll:true});
      }
    };
    const run=async()=>{
      if(matchMedia('(prefers-reduced-motion: reduce)').matches){completed=true;flushSync(()=>{latest.current.onPrepare?.(active);latest.current.onCommit?.(active);});progress.current=target;mountedOpen.current=false;retired.current=false;clear();releaseHandoff();latest.current.onEnd?.(active);restoreFocus();return;}
      const oldSize=interrupted.current??glassLayoutBox(host);interrupted.current=null;
      if(active&&from===0&&latest.current.onPrepare)compact.current=oldSize;
      // In-flow siblings can stretch when a disclosure changes its grid row.
      // Retire their foreground before measuring the target row as well.
      const position=getComputedStyle(host).position;
      if(position!=='fixed'&&position!=='absolute'&&!dialog&&!popover){
        const root=host.closest<HTMLElement>('[data-form-glass-root]');
        if(root)peers.push(...revealLayoutPeers(host,root));
      }
      const shells=[host,...peers];
      const peerBefore=peers.map(node=>({node,rect:node.getBoundingClientRect()}));
      if(!retired.current&&!entering){
        shells.forEach(node=>{node.dataset.glassRevealPhase='hiding';});
        paint=foregroundMotion(shells.flatMap(foregroundRoots),true,config,signal,shells);
        releaseHandoff();
        await paint.finished;if(signal.aborted)return;
      }
      const finishPrepare=beginGlassMeasure('revealPrepare');
      retired.current=true;
      shells.forEach(node=>announcePhase(node,'preparing'));
      releaseHandoff();
      paint?.cancel();paint=undefined;
      const oldPopover=popover?{top:popover.style.top,left:popover.style.left}:undefined;
      restore();
      flushSync(()=>latest.current.onPrepare?.(active));
      const targetSize=glassLayoutBox(host),rect=host.getBoundingClientRect();
      // Capture natural collapsed peers before holding the outgoing full shell.
      // Reading after that hold makes a stretched grid peer appear unchanged,
      // leaving it full-height until the final frame of a close.
      const peerAfter=new Map(peerBefore.map(({node})=>[node,node.getBoundingClientRect()]));
      const finalPopover=popover?{top:popover.style.top,left:popover.style.left}:undefined;
      const full=active?{...targetSize,left:rect.left,top:rect.top}:expanded.current??{...oldSize,left:rect.left,top:rect.top};
      if(active)expanded.current=full;
      const box=latest.current.originBox?.()??compact.current??(!active&&latest.current.onPrepare?targetSize:null)??{width:full.width*config.values['popup-width']/100,height:full.height*config.values['popup-height']/100};
      if(!active){host.style.width=`${full.width}px`;host.style.height=`${full.height}px`;if(popover&&oldPopover)Object.assign(popover.style,oldPopover);}
      const style=getComputedStyle(host),radii=[style.borderTopLeftRadius,style.borderTopRightRadius,style.borderBottomLeftRadius,style.borderBottomRightRadius].map(v=>parseFloat(v)||0),origin=style.transformOrigin.split(' ').map(v=>parseFloat(v)||0);
      const fadeInset=host.dataset.glassFade?Math.max(0,-(parseFloat(style.getPropertyValue('--glass-debug-fade-mid'))||parseFloat(style.getPropertyValue('--glass-fade-mid'))||0)):0;
      if(dialog)dialog.style.height=`${full.height}px`;
      // Build the final material once, then let native nine-slice mask scaling
      // carry it through the entire motion without regenerating SVG fields.
      host.dispatchEvent(new Event('glassgeometrychange'));
      const minimum=nineSliceMinimum(host);
      stopNine=beginNineSlice(host);
      const seed=fitRevealSeed(box,minimum,Boolean(popover));
      const frames=revealGeometryFrames(from,target,full,seed,Math.max(...radii)+fadeInset,dialog||popover?{x:origin[0]/full.width,y:origin[1]/full.height}:{x:0,y:0},config.curve);
      for(const {node,rect:before} of peerBefore){
        const after=peerAfter.get(node)!,saved={width:node.style.width,height:node.style.height,minWidth:node.style.minWidth,minHeight:node.style.minHeight};
        peerRestores.push(()=>Object.assign(node.style,saved));
        node.dispatchEvent(new Event('glassgeometrychange'));peerNine.push(beginNineSlice(node));
        node.style.minWidth='0';node.style.minHeight='0';
        const peerFrames=Array.from({length:61},(_,i)=>{const p=revealProgress(0,1,i/60,config.curve);return {offset:i/60,width:`${before.width+(after.width-before.width)*p}px`,height:`${before.height+(after.height-before.height)*p}px`};});
        const animation=node.animate(peerFrames,{duration,easing:'linear',fill:'both'});animation.pause();animation.currentTime=0;peerMotions.push(animation);
      }
      host.style.padding='0';host.style.minWidth='0';host.style.minHeight='0';
      motion=host.animate(frames,{duration,easing:'linear',fill:'both'});motion.pause();motion.currentTime=0;
      // display:none removes all foreground descendants from layout/paint.
      // Their React instances and values remain mounted and unchanged.
      shells.forEach(node=>{node.dataset.glassRevealPhase='moving';});
      host.dataset.glassRevealing=active?'opening':'closing';
      host.dataset.glassRevealFrom=String(from);host.dataset.glassRevealTo=String(target);
      finishPrepare?.();
      await nextPaint(signal);const start=await nextPaint(signal);
      shells.forEach(node=>announcePhase(node,'moving',{duration,startTime:start,sequential:true}));
      motion.play();motion.startTime=start;
      peerMotions.forEach(animation=>{animation.play();animation.startTime=start;});
      await motion.finished;if(signal.aborted)return;
      progress.current=target;
      // Restore layout underneath zero opacity, before removing the held end
      // frame. This ordering prevents the old expanded rectangle flashing.
      shells.forEach(node=>announcePhase(node,'settling'));
      if(!active&&(dialog||popover)){
        // Remove overlay presence while its compact end frame is still held.
        // Never run an appear phase for a popup that is about to disappear.
        completed=true;mountedOpen.current=false;
        flushSync(()=>{latest.current.onCommit?.(false);latest.current.onEnd?.(false);});
        restore();motion.cancel();motion=undefined;stopNine();stopNine=()=>{};
        clear();return;
      }
      restore();if(popover&&finalPopover)Object.assign(popover.style,finalPopover);
      flushSync(()=>latest.current.onCommit?.(active));motion.cancel();motion=undefined;stopNine();stopNine=()=>{};
      peerMotions.forEach(animation=>animation.cancel());peerRestores.forEach(restore=>restore());peerNine.forEach(stop=>stop());
      host.dispatchEvent(new Event('glassgeometrychange'));
      if(active||latest.current.onPrepare){
        await nextPaint(signal);await nextPaint(signal);
        shells.forEach(node=>{node.dataset.glassRevealPhase='showing';});
        paint=foregroundMotion(shells.flatMap(foregroundRoots),false,config,signal,shells);
        await paint.finished;if(signal.aborted)return;
        retired.current=false;
      }
      completed=true;mountedOpen.current=false;clear();paint?.cancel();paint=undefined;latest.current.onEnd?.(active);
      restoreFocus();
    };
    void nextPaint(signal).then(run).catch(error=>{if(!signal.aborted&&error?.name!=='AbortError'){console.error('Glass transition failed',error);restore();stopNine();clear();}});
    return()=>{
      if(!completed&&requested.current!==active){const rect=host.getBoundingClientRect();interrupted.current={width:rect.width,height:rect.height,left:rect.left,top:rect.top};if(motion)progress.current=revealProgress(from,target,duration>0?Number(motion.currentTime??0)/duration:1,config.curve);}
      const transfer=!completed&&requested.current!==active;
      if(transfer&&paint){paint.freeze();releaseHandoff();handoff.current=paint;}
      abort.abort();if(!transfer){paint?.cancel();releaseHandoff();}motion?.cancel();restore();stopNine();clear();
      peerMotions.forEach(animation=>animation.cancel());peerRestores.forEach(restore=>restore());peerNine.forEach(stop=>stop());
    };
  },[active]);
  return <span ref={anchor} className="glass-reveal-defs" aria-hidden="true"/>;
}
