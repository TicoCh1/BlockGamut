import {useLayoutEffect,useRef,useState} from 'react';

/** A masked mechanical digit drum, with separate wheels for carrying digits. */
export function InstrumentNumber({value,digits=2}:{value:number;digits?:number}) {
  const previous=useRef(value), serial=useRef(0);
  const [roll,setRoll]=useState({from:value,to:value,direction:'up',id:0});
  useLayoutEffect(()=>{
    if(previous.current===value)return;
    const from=previous.current;previous.current=value;
    setRoll({from,to:value,direction:value>=from?'up':'down',id:++serial.current});
    const timer=window.setTimeout(()=>setRoll(current=>current.to===value?{...current,from:value}:current),420);
    return ()=>clearTimeout(timer);
  },[value]);
  const width=Math.max(digits,String(roll.from).length,String(roll.to).length);
  const from=String(roll.from).padStart(width,'0'),to=String(roll.to).padStart(width,'0');
  return <strong className="instrument-number" data-instrument-display="" aria-label={String(value).padStart(digits,'0')}>
    {Array.from({length:width},(_,i)=>{
      const moving=from[i]!==to[i];
      return <span className="instrument-column" aria-hidden="true" key={i}><span key={`${roll.id}/${i}`} className={`instrument-strip ${moving?`is-rolling roll-${roll.direction}`:''}`}>
        {moving?<><span>{roll.direction==='up'?from[i]:to[i]}</span><span>{roll.direction==='up'?to[i]:from[i]}</span></>:<span>{to[i]}</span>}
      </span></span>;
    })}
  </strong>;
}
