/** One material runtime per document; consumers need no particular mount ID. */
export function getGlassRoot(): HTMLElement {
  return document.querySelector<HTMLElement>('[data-form-glass-root]') ?? document.getElementById('root') ?? document.body;
}
export const GLASS_ROOT_SELECTOR = ':is(#root,[data-form-glass-root])';
