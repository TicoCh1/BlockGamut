/** Fine-control scale: the new 100% equals the former 10%. */
export function grainOpacity(intensity:number,blur:number) {
  return Math.min(1,Math.max(0,intensity)/1000*Math.min(1.5,Math.max(0,blur)/8));
}
