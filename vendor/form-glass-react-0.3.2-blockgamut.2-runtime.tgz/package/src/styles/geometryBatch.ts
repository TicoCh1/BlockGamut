type Reader=(entry:ResizeObserverEntry)=>undefined|(()=>void);
const readers=new Map<Element,Set<Reader>>();
let observer:ResizeObserver|undefined;
/** All geometry reads precede all mask writes in one observer delivery. */
export function observeMaterialGeometry(host:HTMLElement,read:Reader){
  observer??=new ResizeObserver(entries=>{
    const writes=entries.flatMap(entry=>[...(readers.get(entry.target)??[])].map(read=>read(entry)));
    writes.forEach(write=>write?.());
  });
  let group=readers.get(host);if(!group){group=new Set();readers.set(host,group);observer.observe(host);}group.add(read);
  return ()=>{group.delete(read);if(!group.size){readers.delete(host);observer?.unobserve(host);}if(!readers.size){observer?.disconnect();observer=undefined;}};
}
