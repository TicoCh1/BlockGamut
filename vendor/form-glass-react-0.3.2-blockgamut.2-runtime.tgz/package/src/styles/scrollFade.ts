import { glassFadeProgress, GLASS_FADE_STEPS, type GlassFadeCurve } from './glassFade.ts';

/** Whole paint targets fade before crossing the scroll clip. Only opacity is
 * animated, so the browser can track scrolling without JS geometry updates. */
export function scrollFadeKeyframes(viewport: number, height: number, distance: number, mid: number, curve: GlassFadeCurve, opacity = 1, bounds?: { top: number; range: number }) {
  const total = viewport + height;
  if (total <= 0 || distance <= 0) return [{ offset: 0, opacity }, { offset: 1, opacity }];
  const shift = Math.min(0, mid);
  const offsets = new Set([0, 1, .5]);
  for (let i = 0; i <= GLASS_FADE_STEPS; i++) {
    const clearance = distance * i / GLASS_FADE_STEPS - shift;
    offsets.add(Math.max(0, Math.min(1, (height + clearance) / total)));
    offsets.add(Math.max(0, Math.min(1, (viewport - clearance) / total)));
    if (bounds) {
      const release = (distance - shift) * i / GLASS_FADE_STEPS;
      offsets.add(Math.max(0, Math.min(1, (viewport - bounds.top + release) / total)));
      offsets.add(Math.max(0, Math.min(1, (viewport - bounds.top + bounds.range - release) / total)));
    }
  }
  return [...offsets].sort((a, b) => a - b).map(offset => {
    const clearance = Math.min(offset * total - height, viewport - offset * total);
    let alpha = glassFadeProgress((clearance + shift) / distance, curve);
    if (bounds) {
      const top = viewport - offset * total, bottom = top + height;
      const scroll = Math.max(0, Math.min(bounds.range, offset * total - (viewport - bounds.top)));
      const release = distance - shift;
      const topMix = Math.min(1, scroll / release), bottomMix = Math.min(1, (bounds.range - scroll) / release);
      const topAlpha = glassFadeProgress((top + shift) / distance, curve);
      const bottomAlpha = glassFadeProgress((viewport - bottom + shift) / distance, curve);
      alpha = top >= viewport || bottom <= 0 ? 0 : Math.min(1 + (topAlpha - 1) * topMix, 1 + (bottomAlpha - 1) * bottomMix);
    }
    return { offset, opacity: opacity * alpha };
  });
}

export type ViewTimelineConstructor = new (options: { subject: Element; axis: string; inset: string }) => AnimationTimeline;
export function nativeViewTimeline(): ViewTimelineConstructor | undefined {
  return (window as unknown as { ViewTimeline?: ViewTimelineConstructor }).ViewTimeline;
}
export type ScrollTimelineConstructor = new (options: { source: Element; axis: string }) => AnimationTimeline;
export function nativeScrollTimeline(): ScrollTimelineConstructor | undefined {
  return (window as unknown as { ScrollTimeline?: ScrollTimelineConstructor }).ScrollTimeline;
}
