import { glassFadeProgress, GLASS_FADE_STEPS, type GlassFadeCurve } from './glassFade.ts';

export type FeatherGeometry = { width: number; height: number; radius: number; corners?: readonly [number,number,number,number]; edges: readonly string[]; distance: number; mid: number; blur: number; curve: GlassFadeCurve };

/** r is signed distance inward from the original outline. Positive k expands
 * the material, negative k contracts it, without changing transition width. */
export function shiftedFade(r: number, distance: number, mid: number, curve: GlassFadeCurve) {
  return distance > 0 ? glassFadeProgress((r + distance + mid) / distance, curve) : Number(r >= 0);
}

/** One vector image for the entire alpha field, not independently composited
 * CSS tiles. Shared rect boundaries rasterize together with crispEdges. The
 * gradients remain continuous; only internal partition edges are snapped.
 * No backdrop pixels are read, encoded or cached by this module. */
export function featherMask(g: FeatherGeometry) {
  const { width: w, height: h, distance: f, mid: k, blur, curve } = g;
  const edges = ['top', 'right', 'bottom', 'left'].map(e => Number(g.edges.includes(e)));
  const [t, r, b, l] = edges;
  const pad = Math.ceil(3 * blur + 2);
  const extent = Math.max(0, f + k);
  const inset = edges.map(e => pad + extent * e);
  const x0 = inset[3] - k * l, y0 = inset[0] - k * t;
  const x1 = inset[3] + w + k * r, y1 = inset[0] + h + k * b;
  const width = w + inset[1] + inset[3], height = h + inset[0] + inset[2];
  const radius = Math.max(0, Math.min((g.corners ? Math.max(...g.corners) : g.radius) + (edges.every(Boolean) ? k : 0), (x1 - x0) / 2, (y1 - y0) / 2));
  // Selectively square corners share the same tile bounds; their alpha follows
  // the selected straight edge rather than introducing a radial round-off.
  const cornerFill = (index: number, id: string, a: number, aId: string, b: number, bId: string) => g.corners?.[index] === 0 && !(a && b) ? a ? `url(#${aId})` : b ? `url(#${bId})` : 'white' : `url(#${id})`;
  const left = x0 - f * l, top = y0 - f * t, right = x1 + f * r, bottom = y1 + f * b;
  const xl = x0 + radius, xr = x1 - radius, yt = y0 + radius, yb = y1 - radius;
  const n = (v: number) => String(Number(v.toFixed(5)));
  const stops = (radial = false, fade = f) => Array.from({ length: GLASS_FADE_STEPS + 1 }, (_, i) => {
    const u = i / GLASS_FADE_STEPS;
    const offset = radial ? (radius + fade * u) / (radius + fade || 1) : u;
    return `<stop offset="${n(offset)}" stop-color="white" stop-opacity="${n(glassFadeProgress(radial ? 1 - u : u, curve))}"/>`;
  }).join('');
  const gradient = (id: string, a: number, c: number, d: number, e: number) => `<linearGradient id="${id}" gradientUnits="userSpaceOnUse" x1="${n(a)}" y1="${n(c)}" x2="${n(d)}" y2="${n(e)}">${stops()}</linearGradient>`;
  const corner = (id: string, cx: number, cy: number, fade: number) => `<radialGradient id="${id}" gradientUnits="userSpaceOnUse" cx="${n(cx)}" cy="${n(cy)}" r="${n(Math.max(.0001, radius + fade))}"><stop offset="0" stop-color="white"/>${stops(true, fade)}</radialGradient>`;
  const rect = (x: number, y: number, xEnd: number, yEnd: number, fill: string) => xEnd > x && yEnd > y ? `<rect x="${n(x)}" y="${n(y)}" width="${n(xEnd - x)}" height="${n(yEnd - y)}" fill="${fill}"/>` : '';
  const defs = gradient('t', 0, top, 0, y0) + gradient('r', right, 0, x1, 0) + gradient('b', 0, bottom, 0, y1) + gradient('l', left, 0, x0, 0)
    + corner('tl', xl, yt, f * Math.max(t, l)) + corner('tr', xr, yt, f * Math.max(t, r))
    + corner('br', xr, yb, f * Math.max(b, r)) + corner('bl', xl, yb, f * Math.max(b, l));
  const tiles = x1 > x0 && y1 > y0 ? rect(left, top, xl, yt, cornerFill(0,'tl',t,'t',l,'l')) + rect(xr, top, right, yt, cornerFill(1,'tr',t,'t',r,'r'))
    + rect(xr, yb, right, bottom, cornerFill(2,'br',b,'b',r,'r')) + rect(left, yb, xl, bottom, cornerFill(3,'bl',b,'b',l,'l'))
    + rect(xl, top, xr, yt, t ? 'url(#t)' : 'white') + rect(xr, yt, right, yb, r ? 'url(#r)' : 'white')
    + rect(xl, yb, xr, bottom, b ? 'url(#b)' : 'white') + rect(left, yt, xl, yb, l ? 'url(#l)' : 'white')
    + rect(xl, yt, xr, yb, 'white') : '';
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${n(width)}" height="${n(height)}" viewBox="0 0 ${n(width)} ${n(height)}"><defs>${defs}</defs><g shape-rendering="crispEdges">${tiles}</g></svg>`;
  return { inset, svg, empty: !tiles, url: `url("data:image/svg+xml,${encodeURIComponent(svg)}")` };
}
