import type {FeatherGeometry} from './featherMask';
import type {MaterialChannel} from './materialFade';

export type NineSlice={url:string;width:number;height:number;cuts:readonly number[];inset:readonly number[]};
type Recipe={blur:NineSlice;contrast:NineSlice;brightness:NineSlice};
const recipes=new WeakMap<HTMLElement,Recipe>();
const active=new WeakMap<HTMLElement,Recipe>();
/** Partition at the exact centres of the existing radial corner gradients.
 * The original SVG is reused; four corners never scale, edges stretch on one
 * axis and the opaque centre stretches on both. No additional filter pass. */
export function nineSlice(g:FeatherGeometry,inset:readonly number[],url:string):NineSlice{
  const edges=['top','right','bottom','left'].map(e=>Number(g.edges.includes(e)));
  const radius=Math.max(0,Math.min((g.corners?Math.max(...g.corners):g.radius)+(edges.every(Boolean)?g.mid:0),
    (g.width+g.mid*(edges[1]+edges[3]))/2,(g.height+g.mid*(edges[0]+edges[2]))/2));
  return {url,inset,width:g.width+inset[1]+inset[3],height:g.height+inset[0]+inset[2],cuts:inset.map((v,i)=>v-g.mid*edges[i]+radius)};
}
export function nineSliceMinimum(host:HTMLElement){
  const renderer=host.querySelector<HTMLElement>(':scope > .glass-renderer'),recipe=renderer&&recipes.get(renderer);
  const parts=recipe?Object.values(recipe):[];
  return {width:Math.max(0,...parts.map(p=>p.cuts[1]+p.cuts[3]-p.inset[1]-p.inset[3])),height:Math.max(0,...parts.map(p=>p.cuts[0]+p.cuts[2]-p.inset[0]-p.inset[2]))};
}
export function registerNineSlice(renderer:HTMLElement,recipe:Recipe){recipes.set(renderer,recipe);}
export function activeNineSlice(renderer:HTMLElement,channel:MaterialChannel){return active.get(renderer)?.[channel];}
export function beginNineSlice(host:HTMLElement){
  const renderer=host.querySelector<HTMLElement>(':scope > .glass-renderer');
  const recipe=renderer&&recipes.get(renderer);
  if(!renderer||!recipe||document.documentElement.dataset.glassBlurEngine!=='lerp'||!CSS.supports('-webkit-mask-box-image-source','none'))return ()=>{};
  const layers=renderer.querySelectorAll<HTMLElement>('.glass-blur-layer');
  const entries=renderer.hasAttribute('data-separate-fades')?[[layers[5],recipe.blur],[layers[6],recipe.contrast],[layers[7],recipe.brightness]] as const:[[layers[7],recipe.blur]] as const;
  const saved=entries.map(([layer])=>({layer,css:layer.style.cssText}));
  for(const [layer,part] of entries){
    // mask-box-image owns the alpha only during shell motion. Keep the same
    // filtering element/backdrop root, including independent tone passes.
    layer.style.setProperty('mask-image','none','important');
    layer.style.setProperty('-webkit-mask-box-image-source',part.url);
    layer.style.setProperty('-webkit-mask-box-image-slice',`${part.cuts.join(' ')} fill`);
    layer.style.setProperty('-webkit-mask-box-image-width',part.cuts.map(v=>`${v}px`).join(' '));
    layer.style.setProperty('-webkit-mask-box-image-outset','0');
    layer.style.setProperty('-webkit-mask-box-image-repeat','stretch');
  }
  renderer.dataset.nineSlice='';active.set(renderer,recipe);
  return ()=>{saved.forEach(({layer,css})=>{layer.style.cssText=css;});active.delete(renderer);delete renderer.dataset.nineSlice;host.dispatchEvent(new Event('glassgeometrychange'));};
}
/** Object exemption uses exactly the same nine rectangles as native CSS. */
export function drawNineSlice(ctx:CanvasRenderingContext2D,image:CanvasImageSource,part:NineSlice,x:number,y:number,width:number,height:number){
  const [t,r,b,l]=part.cuts;
  const sx=[0,l,part.width-r,part.width],sy=[0,t,part.height-b,part.height];
  const dx=[x,x+l,x+width-r,x+width],dy=[y,y+t,y+height-b,y+height];
  for(let row=0;row<3;row++)for(let col=0;col<3;col++){
    const sw=sx[col+1]-sx[col],sh=sy[row+1]-sy[row],dw=dx[col+1]-dx[col],dh=dy[row+1]-dy[row];
    if(sw>0&&sh>0&&dw>0&&dh>0)ctx.drawImage(image,sx[col],sy[row],sw,sh,dx[col],dy[row],dw,dh);
  }
}
