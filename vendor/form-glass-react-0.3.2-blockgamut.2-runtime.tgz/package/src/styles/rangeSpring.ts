export type RangeSpring={position:number;velocity:number};

/** Exact underdamped spring step. Frame-rate independent; no Euler drift.
 * The spring controls deformation only: thumb position stays under the pointer. */
export function advanceRangeSpring(state:RangeSpring,target:number,seconds:number):RangeSpring {
  const dt=Math.max(0,Math.min(.064,seconds)), omega=24, damping=.62;
  const decay=damping*omega, frequency=omega*Math.sqrt(1-damping*damping);
  const offset=state.position-target, envelope=Math.exp(-decay*dt);
  const cosine=Math.cos(frequency*dt), sine=Math.sin(frequency*dt);
  return {
    position:target+envelope*(offset*cosine+(state.velocity+decay*offset)/frequency*sine),
    velocity:envelope*(state.velocity*cosine-(decay*state.velocity+omega*omega*offset)/frequency*sine)
  };
}
