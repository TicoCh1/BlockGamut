export type PaintRect={left:number;top:number;right:number;bottom:number;width:number;height:number};
/** Conservative opaque core. Avoid sampling the curved corner altogether;
 * false negatives cost a mask, false positives would change visible paint. */
export function insideOpaqueGlass(paint:PaintRect,host:PaintRect,edges:readonly string[],radius:number,mid:number){
  const r=Math.max(0,Math.min(radius,host.width/2,host.height/2));
  const inset=(edge:string)=>edges.includes(edge)?Math.max(0,-mid)+r:r;
  return paint.left>=host.left+inset('left')&&paint.right<=host.right-inset('right')&&paint.top>=host.top+inset('top')&&paint.bottom<=host.bottom-inset('bottom');
}
