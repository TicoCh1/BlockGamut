export function scrollGeometry(viewport: number, content: number, position: number, track: number, minimum = 40) {
  const range = Math.max(0, content - viewport);
  const length = Math.min(track, Math.max(minimum, content > 0 ? track * viewport / content : track));
  const travel = Math.max(0, track - length);
  const value = Math.max(0, Math.min(range, position));
  return { range, length, travel, value, offset: range > 0 ? travel * value / range : 0, visible: range > 1 && travel > 0 };
}

export function scrollFromThumb(offset: number, range: number, travel: number) {
  return travel > 0 ? Math.max(0, Math.min(range, offset * range / travel)) : 0;
}
