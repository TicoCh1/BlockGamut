import { glassFadeProgress, type GlassFadeCurve } from './glassFade.ts';

export type ContactObject = {
  id:string; label:string; src:string; x:number; y:number; width:number; height:number;
  exempt:boolean; strength:number; distance:number; mid:number;
};
export const DEFAULT_CONTACT_EXEMPTION = { exempt:true, strength:100, distance:32, mid:-32 } as const;
export function contactAmount(object:ContactObject,x:number,y:number,curve:GlassFadeCurve='smootherstep') {
  if(!object.exempt)return 0;
  const r=Math.min(x-object.x,object.x+object.width-x,y-object.y,object.y+object.height-y);
  const a=object.distance>0?glassFadeProgress((r+object.distance+object.mid)/object.distance,curve):Number(r>=0);
  return Math.max(0,Math.min(1,a))*Math.max(0,Math.min(1,object.strength/100));
}
/** This weight belongs to one sprite, never to the glass/background mask. */
export function contactMaterialWeight(object:ContactObject,x:number,y:number,glassAlpha:number,curve:GlassFadeCurve='smootherstep') {
  return Math.max(0,Math.min(1,glassAlpha))*(1-contactAmount(object,x,y,curve));
}
export const contactBlurWeight=contactMaterialWeight;
export function clampContactPosition(x:number,y:number,width:number,height:number,viewportWidth:number,viewportHeight:number) {
  return {x:Math.max(8,Math.min(viewportWidth-width-8,x)),y:Math.max(72,Math.min(viewportHeight-height-48,y))};
}
