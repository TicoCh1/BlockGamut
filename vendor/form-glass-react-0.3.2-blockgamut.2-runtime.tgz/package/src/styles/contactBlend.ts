/** Premultiplied RGBA lerp, including silhouette alpha. Source-over would
 * leave an opaque base edge underneath the transparent blurred endpoint.
 * Add the two complementary contributions without attenuating them twice. */
export function mixContactLayer(base:CanvasRenderingContext2D,processed:CanvasRenderingContext2D,weight:HTMLCanvasElement) {
  processed.globalCompositeOperation='destination-in';processed.drawImage(weight,0,0);processed.globalCompositeOperation='source-over';
  base.globalCompositeOperation='destination-out';base.drawImage(weight,0,0);
  base.globalCompositeOperation='lighter';base.drawImage(processed.canvas,0,0);base.globalCompositeOperation='source-over';
}
