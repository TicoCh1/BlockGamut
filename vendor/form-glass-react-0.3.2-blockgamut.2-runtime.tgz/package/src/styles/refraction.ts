export const REFRACTION_PARAMETERS = [
  { key: 'strength', label: 'Mirror amount', min: 0, max: 100, step: 1, unit: '%' },
  { key: 'width', label: 'Mirror axis', min: 1, max: 48, step: .5, unit: 'px' },
  { key: 'axisBend', label: 'Axis bend', min: -80, max: 80, step: 1, unit: '%' },
  { key: 'bendSpan', label: 'Bend span', min: 1, max: 48, step: .5, unit: 'px' },
  { key: 'transition', label: 'Outer blend', min: 0, max: 64, step: .5, unit: 'px' },
  { key: 'profile', label: 'Blend curve', min: 1, max: 4, step: .1, unit: '' },
  { key: 'softness', label: 'Map softness', min: 0, max: 1.5, step: .05, unit: 'px' },
  { key: 'cornerRadius', label: 'Square mirror corner', min: 0, max: 8, step: .5, unit: 'px' }
] as const;
export type RefractionValues = Record<typeof REFRACTION_PARAMETERS[number]['key'], number>;
export const DEFAULT_REFRACTION_ENABLED = false;
export const DEFAULT_REFRACTION: RefractionValues = { strength: 100, width: 16, axisBend: 30, bendSpan: 1, transition: 8, profile: 1, softness: .35, cornerRadius: 3 };
export const NO_REFRACTION: RefractionValues = { ...DEFAULT_REFRACTION, strength: 0 };

/** Signed inward distance r: outside the inset axis a, sample 2a-r.
 * Inside the axis, sample r unchanged. Only the exterior blend relaxes this
 * fold back to identity, so the mirror itself remains linear and symmetric. */
/** Compact, C1-continuous change to source spacing beside the fold axis.
 * Positive bend compresses the reflected pattern near the axis, then relaxes;
 * negative bend expands it. Source order remains monotone at the UI limits. */
export function axisBendOffset(distance:number,amount:number,span:number) {
  if(distance<=0||span<=0||distance>=span)return 0;
  const t=distance/span,weight=(1-t*t)**2;
  return Math.max(-.8,Math.min(.8,amount/100))*distance*weight;
}
export function mirrorOffset(distance: number, axis: number, transition: number, curve: number, bend=0, span=18) {
  if (distance >= axis || axis <= 0) return 0;
  const folded=2*(axis-distance)+axisBendOffset(axis-distance,bend,span);
  if (distance >= 0) return folded;
  if (transition <= 0 || distance <= -transition) return 0;
  const t = 1 + distance / transition;
  const blend = Math.pow(t * t * (3 - 2 * t), curve);
  return folded * blend;
}
export const REFRACTION_EDGES = ['top','right','bottom','left'] as const;
export type RefractionEdge = typeof REFRACTION_EDGES[number];
export function selectedRefractionEdges(edges?:readonly RefractionEdge[]) {
  return REFRACTION_EDGES.filter(edge=>(edges??REFRACTION_EDGES).includes(edge));
}
function cornerEdges(index:number):readonly [RefractionEdge,RefractionEdge] {
  return [['top','left'],['top','right'],['bottom','right'],['bottom','left']][index] as [RefractionEdge,RefractionEdge];
}
export type CornerRadii = readonly [number,number,number,number];
export type RefractionGeometry = { width: number; height: number; offsetX: number; offsetY: number; renderWidth: number; renderHeight: number; corners?: CornerRadii; outlineCorners?: CornerRadii; edges?: readonly RefractionEdge[] };
export function fitCornerRadii(width: number, height: number, corners: CornerRadii): CornerRadii {
  return corners.map(r => Math.max(0,Math.min(r,width/2,height/2))) as unknown as CornerRadii;
}
/** A tiny optical bevel for four-edge square surfaces only. These radii belong
 * to the displacement map, never to the material silhouette or hit area.
 * The caller supplies zero bevel when fade is disabled. */
export function mirrorCornerRadii(width:number,height:number,corners:CornerRadii,edges:readonly RefractionEdge[]|undefined,bevel:number):CornerRadii {
  const outline=fitCornerRadii(width,height,corners);
  if(selectedRefractionEdges(edges).length!==4||outline.some(r=>r>0))return outline;
  return fitCornerRadii(width,height,[bevel,bevel,bevel,bevel]);
}
export function mirrorGeometry(width: number, height: number, values: RefractionValues, _corners?: CornerRadii) {
  const axis = Math.min(values.width,width/2,height/2);
  return { axis, amplitude: Math.max(.001,(2+Math.abs(values.axisBend)/100)*(axis+values.transition)) };
}
export function displacementScale(width: number, height: number, values: RefractionValues, corners?: CornerRadii) {
  return 2*mirrorGeometry(width,height,values,corners).amplitude*values.strength/100;
}
export function outlineDistance(x: number, y: number, width: number, height: number, corners: CornerRadii) {
  const [tl,tr,br,bl]=corners;
  if(tl>0&&x<tl&&y<tl)return tl-Math.hypot(x-tl,y-tl);
  if(tr>0&&x>width-tr&&y<tr)return tr-Math.hypot(x-width+tr,y-tr);
  if(br>0&&x>width-br&&y>height-br)return br-Math.hypot(x-width+br,y-height+br);
  if(bl>0&&x<bl&&y>height-bl)return bl-Math.hypot(x-bl,y-height+bl);
  return Math.min(x,y,width-x,height-y);
}
export function exteriorBlend(distance:number,values:RefractionValues) {
  if(distance>=0)return 1;
  if(values.transition<=0||distance<=-values.transition)return 0;
  const t=1+distance/values.transition;
  return Math.pow(t*t*(3-2*t),values.profile);
}
export function edgeDisplacement(x: number, y: number, width: number, height: number, radius: number | CornerRadii, values: RefractionValues, edges?:readonly RefractionEdge[]) {
  const corners=fitCornerRadii(width,height,typeof radius==='number'?[radius,radius,radius,radius]:radius);
  const {axis}=mirrorGeometry(width,height,values);
  const selected=selectedRefractionEdges(edges);
  for(let i=0;i<4;i++){
    const r=corners[i];if(r<=0||!cornerEdges(i).every(edge=>selected.includes(edge)))continue;
    const right=i===1||i===2,bottom=i>=2,inset=Math.max(r,axis);
    const cx=right?width-inset:inset,cy=bottom?height-inset:inset;
    if((right?x>cx:x<cx)&&(bottom?y>cy:y<cy)){
      const vx=x-cx,vy=y-cy,rho=Math.hypot(vx,vy),axisRadius=Math.max(0,r-axis);
      if(rho===0)return [0,0] as const;
      const distance=Math.max(0,rho-axisRadius);
      const offset=(2*distance+axisBendOffset(distance,values.axisBend,values.bendSpan))*exteriorBlend(outlineDistance(x,y,width,height,corners),values)*values.strength/100;
      return [-vx/rho*offset,-vy/rho*offset] as const;
    }
  }
  const amount=values.strength/100;
  const offset=(r:number)=>mirrorOffset(r,axis,values.transition,values.profile,values.axisBend,values.bendSpan);
  const dx=amount*((selected.includes('left')?offset(x):0)-(selected.includes('right')?offset(width-x):0));
  const dy=amount*((selected.includes('top')?offset(y):0)-(selected.includes('bottom')?offset(height-y):0));
  return [dx===0?0:dx,dy===0?0:dy] as const;
}

/** Corner vector = one inward radial normal times one mirror offset.
 * Linear X/Y coordinate fields are attenuated together by a radial alpha
 * mask. This rotates continuously around the arc without angular wedges,
 * crossing two independent mirrors, canvas sampling, or another filter pass. */
function cornerMap(g: RefractionGeometry, values: RefractionValues, axis: number, amplitude: number) {
  const radii=fitCornerRadii(g.width,g.height,g.corners??[0,0,0,0]);
  const selected=selectedRefractionEdges(g.edges);
  let defs='',paint='';
  const rect=(a:number,b:number,c:number,d:number,fill:string)=>c>a&&d>b?`<rect x="${a}" y="${b}" width="${c-a}" height="${d-b}" fill="${fill}"/>`:'';
  for(let index=0;index<4;index++) {
    const r=radii[index];if(r<=0||!cornerEdges(index).every(edge=>selected.includes(edge)))continue;
    const right=index===1||index===2,bottom=index>=2,deep=axis>=r,inset=Math.max(r,axis);
    const cx=g.offsetX+(right?g.width-inset:inset),cy=g.offsetY+(bottom?g.height-inset:inset);
    const ox=g.offsetX+(right?g.width-r:r),oy=g.offsetY+(bottom?g.height-r:r);
    const x=right?cx:0,y=bottom?cy:0,w=right?g.renderWidth-cx:cx,h=bottom?g.renderHeight-cy:cy;
    const outer=inset+values.transition,inner=r-axis,id=`arc${index}`;
    const cornerOuter=r+values.transition;
    const radiiStops=deep?[0,r,...Array.from({length:16},(_,i)=>r+values.transition*(i+1)/16)]:[0,...Array.from({length:13},(_,i)=>inner+axis*i/12),...Array.from({length:16},(_,i)=>r+values.transition*(i+1)/16)];
    const stops=radiiStops.map(rho=>{
      const alpha=deep?exteriorBlend(r-rho,values):rho>0?outer*mirrorOffset(r-rho,axis,values.transition,values.profile,values.axisBend,values.bendSpan)/(rho*amplitude):0;
      return `<stop offset="${rho/cornerOuter}" stop-color="white" stop-opacity="${Math.max(0,Math.min(1,alpha))}"/>`;
    });
    if(deep&&values.transition===0)stops.push('<stop offset="1" stop-color="white" stop-opacity="0"/>');
    let bendMask='';
    if(deep&&values.axisBend!==0){
      const bendStops=Array.from({length:17},(_,i)=>{const t=i/16;const alpha=(2+values.axisBend/100*(1-t*t)**2)*outer/amplitude;return `<stop offset="${t}" stop-color="white" stop-opacity="${alpha}"/>`;}).join('');
      defs+=`<radialGradient id="${id}bend" gradientUnits="userSpaceOnUse" cx="${cx}" cy="${cy}" r="${values.bendSpan}">${bendStops}</radialGradient><mask id="${id}bendMask" maskUnits="userSpaceOnUse" x="${x}" y="${y}" width="${w}" height="${h}" style="mask-type:alpha"><rect x="${x}" y="${y}" width="${w}" height="${h}" fill="url(#${id}bend)"/></mask>`;
      bendMask=`mask="url(#${id}bendMask)"`;
    }
    const bounds=`x="${x}" y="${y}" width="${w}" height="${h}"`;
    let mask=rect(x,y,x+w,y+h,`url(#${id}a)`);
    if(deep){
      // The inset arc has collapsed to a point, which keeps moving inward.
      // Its outer fade still follows the original circular/straight outline.
      const xs=right?[ox,g.renderWidth]:[0,ox],xi=right?[cx,ox]:[ox,cx];
      const ys=bottom?[oy,g.renderHeight]:[0,oy],yi=bottom?[cy,oy]:[oy,cy];
      const edgeX=g.offsetX+(right?g.width:0),edgeY=g.offsetY+(bottom?g.height:0);
      const fadeStops=Array.from({length:17},(_,i)=>{const t=i/16;return `<stop offset="${t}" stop-color="white" stop-opacity="${Math.pow(t*t*(3-2*t),values.profile)}"/>`;}).join('');
      const span=Math.max(.0001,values.transition);
      defs+=`<linearGradient id="${id}fx" gradientUnits="userSpaceOnUse" x1="${edgeX+(right?span:-span)}" x2="${edgeX}">${fadeStops}</linearGradient>
      <linearGradient id="${id}fy" gradientUnits="userSpaceOnUse" x1="0" x2="0" y1="${edgeY+(bottom?span:-span)}" y2="${edgeY}">${fadeStops}</linearGradient>`;
      mask=rect(xs[0],ys[0],xs[1],ys[1],`url(#${id}a)`)+rect(xi[0],ys[0],xi[1],ys[1],`url(#${id}fy)`)+rect(xs[0],yi[0],xs[1],yi[1],`url(#${id}fx)`)+rect(xi[0],yi[0],xi[1],yi[1],'white');
    }
    defs+=`<linearGradient id="${id}x" gradientUnits="userSpaceOnUse" x1="${cx-outer}" x2="${cx+outer}"><stop stop-color="rgb(255,255,255)"/><stop offset="1" stop-color="rgb(1,255,255)"/></linearGradient>
    <linearGradient id="${id}y" gradientUnits="userSpaceOnUse" x1="0" x2="0" y1="${cy-outer}" y2="${cy+outer}"><stop stop-color="rgb(255,255,255)"/><stop offset="1" stop-color="rgb(255,1,255)"/></linearGradient>
    <radialGradient id="${id}a" gradientUnits="userSpaceOnUse" cx="${ox}" cy="${oy}" r="${cornerOuter}">${stops.join('')}</radialGradient>
    <mask id="${id}m" maskUnits="userSpaceOnUse" x="${x}" y="${y}" width="${w}" height="${h}" style="mask-type:alpha"><g shape-rendering="crispEdges">${mask}</g></mask>`;
    paint+=`<g style="isolation:isolate"><rect ${bounds} fill="rgb(128,128,255)"/><g mask="url(#${id}m)"><g ${bendMask} style="isolation:isolate"><rect ${bounds} fill="url(#${id}x)"/><rect ${bounds} fill="url(#${id}y)" style="mix-blend-mode:multiply"/></g></g></g>`;
  }
  return {defs,paint};
}

const maps = new Map<string, string>();
/** Four straight strips and continuous radial corner fields encode reflected sampling in R/G.
 * The interior segment has two stops: its displacement is exactly linear.
 * Exterior stops smooth the return to the original background. No pixel loops
 * or per-frame map updates; strength and softness reuse the same vector map. */
export function displacementMap(g: RefractionGeometry, values: RefractionValues) {
  const key = [g.width, g.height, g.offsetX, g.offsetY, g.renderWidth, g.renderHeight, values.width, values.transition, values.profile, values.axisBend, values.bendSpan, ...(g.corners??[0,0,0,0]), selectedRefractionEdges(g.edges).join(' ')].join(':');
  const cached = maps.get(key);
  if (cached) return cached;
  const { axis, amplitude } = mirrorGeometry(g.width, g.height, values, g.corners);
  const band = axis + values.transition;
  const arcs=cornerMap(g,values,axis,amplitude);
  const selected=selectedRefractionEdges(g.edges);
  const color = (channel: 'R' | 'G', sign: number, displacement: number) => {
    const v = 128 + sign * 127 * displacement / amplitude;
    return channel === 'R' ? `rgb(${v},255,255)` : `rgb(255,${v},255)`;
  };
  const stops = (channel: 'R' | 'G', sign: number) => {
    const distances = values.transition > 0 ? Array.from({length: 17}, (_, i) => -values.transition + values.transition * i / 16) : [0];
    distances.push(...(values.axisBend===0?[axis]:Array.from({length:16},(_,i)=>axis*(i+1)/16)));
    return distances.map(r => `<stop offset="${(r + values.transition) / band}" stop-color="${color(channel, sign, mirrorOffset(r, axis, values.transition, values.profile, values.axisBend, values.bendSpan))}"/>`).join('');
  };
  const { width: w, height: h, offsetX: x, offsetY: y, renderWidth: rw, renderHeight: rh } = g;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${rw}" height="${rh}" viewBox="0 0 ${rw} ${rh}" style="isolation:isolate" color-interpolation="sRGB"><defs>
  <linearGradient id="l">${stops('R', 1)}</linearGradient><linearGradient id="r" x1="1" x2="0">${stops('R', -1)}</linearGradient>
  <linearGradient id="t" x2="0" y2="1">${stops('G', 1)}</linearGradient><linearGradient id="b" x2="0" y1="1" y2="0">${stops('G', -1)}</linearGradient>${arcs.defs}</defs>
  <g><rect width="${rw}" height="${rh}" fill="rgb(128,255,255)"/>${selected.includes('left')?`<rect x="${x-values.transition}" width="${band}" height="${rh}" fill="url(#l)"/>`:''}${selected.includes('right')?`<rect x="${x+w-axis}" width="${band}" height="${rh}" fill="url(#r)"/>`:''}</g>
  <g style="mix-blend-mode:multiply"><rect width="${rw}" height="${rh}" fill="rgb(255,128,255)"/>${selected.includes('top')?`<rect y="${y-values.transition}" width="${rw}" height="${band}" fill="url(#t)"/>`:''}${selected.includes('bottom')?`<rect y="${y+h-axis}" width="${rw}" height="${band}" fill="url(#b)"/>`:''}</g>${arcs.paint}</svg>`;
  const uri = `data:image/svg+xml,${encodeURIComponent(svg)}`;
  if (maps.size >= 64) maps.delete(maps.keys().next().value!);
  maps.set(key, uri);
  return uri;
}
