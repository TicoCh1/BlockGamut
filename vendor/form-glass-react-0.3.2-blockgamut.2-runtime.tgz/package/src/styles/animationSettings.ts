import type { GlassFadeCurve } from './glassFade';

export const ANIMATION_PARAMETERS=[
  {key:'blur-out',label:'Blur out duration',min:0,max:1200,step:10,unit:'ms',group:'Disappear'},
  {key:'fade-out',label:'Fade out duration',min:0,max:1200,step:10,unit:'ms',group:'Disappear'},
  {key:'content-blur',label:'Content blur limit',min:0,max:128,step:1,unit:'px',group:'Disappear'},
  {key:'open',label:'Expand duration',min:0,max:2000,step:10,unit:'ms',group:'Glass motion'},
  {key:'close',label:'Contract duration',min:0,max:2000,step:10,unit:'ms',group:'Glass motion'},
  {key:'popup-width',label:'Dialog closed width',min:10,max:100,step:1,unit:'%',group:'Glass motion'},
  {key:'popup-height',label:'Dialog closed height',min:10,max:100,step:1,unit:'%',group:'Glass motion'}
] as const;
export type AnimationParameter=typeof ANIMATION_PARAMETERS[number]['key'];
export type AnimationValues=Record<AnimationParameter,number>;
export type AnimationSettings={values:AnimationValues;curve:GlassFadeCurve};
export const DEFAULT_ANIMATION_SETTINGS:AnimationSettings={curve:'smootherstep',values:{'blur-out':350,'fade-out':150,'content-blur':16,open:250,close:250,'popup-width':10,'popup-height':10}};
export function animationContentTiming(settings:AnimationSettings,hiding:boolean){
  const first=settings.values[hiding?'blur-out':'fade-out'],second=settings.values[hiding?'fade-out':'blur-out'];
  return {duration:first+second,split:first+second>0?first/(first+second):.5,hiding,curve:settings.curve};
}
