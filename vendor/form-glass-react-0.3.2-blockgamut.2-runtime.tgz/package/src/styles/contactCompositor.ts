import {getGlassRoot,GLASS_ROOT_SELECTOR} from './glassRoot';
import grainUrl from '../assets/glass-grain.png';
import { featherMask } from './featherMask';
import type { GlassFadeCurve } from './glassFade';
import type { GlassValues } from './glassSettings';
import type { ContactObject } from './contactField';
import { grainOpacity } from './grain';
import { mixContactLayer } from './contactBlend';
import {beginGlassMeasure} from './performanceProbe';
import {activeNineSlice,drawNineSlice} from './nineSlice';

type Buffer={canvas:HTMLCanvasElement;ctx:CanvasRenderingContext2D};
type Sprite=Buffer&{inset:number};
type ObjectPlane=Buffer&{left:number;top:number};
type CachedLayer=Buffer&{key:string;version:number};
type Surface={canvas:HTMLCanvasElement;ctx:CanvasRenderingContext2D;work:Buffer;weight:Buffer;fold:Buffer;object:Buffer;layers:Map<string,CachedLayer>};
const buffer=():Buffer=>{const canvas=document.createElement('canvas');return {canvas,ctx:canvas.getContext('2d')!};};
function resize(b:Buffer,w:number,h:number){if(b.canvas.width!==w)b.canvas.width=w;if(b.canvas.height!==h)b.canvas.height=h;b.ctx.clearRect(0,0,w,h);b.ctx.filter='none';b.ctx.globalAlpha=1;b.ctx.globalCompositeOperation='source-over';}
function overlap(o:ContactObject,r:DOMRect){return o.x<r.right&&o.x+o.width>r.left&&o.y<r.bottom&&o.y+o.height>r.top;}
function alignedRect(bounds:DOMRect){
  const ratio=devicePixelRatio||1;let grid=1;
  while(grid<16&&Math.abs(grid*ratio-Math.round(grid*ratio))>1e-5)grid++;
  if(Math.abs(grid*ratio-Math.round(grid*ratio))>1e-5)grid=1;
  const left=Math.floor(bounds.left/grid)*grid,top=Math.floor(bounds.top/grid)*grid;
  return new DOMRect(left,top,Math.ceil(bounds.right/grid)*grid-left,Math.ceil(bounds.bottom/grid)*grid-top);
}
function imageUrl(css:string){const match=css.match(/^url\(["']?(.*?)["']?\)$/);return match?.[1]??'';}
/** Match CSS stacking contexts, including portals and top-layer menus. DOM
 * order alone puts a portalled draggable panel above the parameter dock. */
function stackPath(node:HTMLElement){const path:number[]=[];for(let n:HTMLElement|null=node.parentElement;n;n=n.parentElement){const s=getComputedStyle(n);if(n.matches(':popover-open'))path.unshift(1e9);else if(s.isolation==='isolate'||s.zIndex!=='auto'||s.transform!=='none')path.unshift(Number.parseInt(s.zIndex)||0);}return path;}
function paintOrder(a:HTMLElement,b:HTMLElement,paths:Map<HTMLElement,number[]>){const aa=paths.get(a)!,bb=paths.get(b)!;for(let i=0;i<Math.min(aa.length,bb.length);i++)if(aa[i]!==bb[i])return aa[i]-bb[i];return a.compareDocumentPosition(b)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1;}

/** Object-only compositor. The real glass continues to sample the unmodified
 * DOM backdrop. Independent sprite paint is inserted after material and before
 * foreground, so an exemption can never clear another object or the photo.
 * Source sprites/blur endpoints are prepared once per settings change. Motion
 * only translates them and updates small local alpha composites. */
export function createContactCompositor(world:HTMLCanvasElement,read:()=>ContactObject[],settings:{values:GlassValues;curve:GlassFadeCurve;glassEnabled:boolean}) {
  const ctx=world.getContext('2d')!;
  const surfaces=new Map<HTMLElement,Surface>(),images=new Map<string,HTMLImageElement>(),sprites=new Map<string,Sprite>(),fields=new Map<string,ReturnType<typeof featherMask>>(),planes=new Map<string,ObjectPlane>();
  let frame=0,disposed=false,assetRevision=0,layerVersion=0;
  const moving=new Set<HTMLElement>();
  const schedule=()=>{if(!disposed&&!frame)frame=requestAnimationFrame(paint);};
  function image(src:string){let img=images.get(src);if(!img){img=new Image();img.onload=()=>{assetRevision++;schedule();};img.src=src;images.set(src,img);}return img.complete&&img.naturalWidth>0?img:null;}
  const grain=image(grainUrl);
  const grainPatterns=new WeakMap<CanvasRenderingContext2D,CanvasPattern>();
  function sprite(o:ContactObject,blur:number) {
    const key=`${o.src}/${o.width}/${o.height}/${blur}`;
    const cached=sprites.get(key);if(cached)return cached;
    const img=image(new URL(o.src,document.baseURI).href);if(!img)return null;
    const pad=blur>0?Math.ceil(3*blur+2):0;
    const tile:Sprite={...buffer(),inset:pad};resize(tile,Math.ceil(o.width+2*pad),Math.ceil(o.height+2*pad));
    const aspect=img.naturalWidth/img.naturalHeight, target=o.width/o.height;
    const sw=aspect>target?img.naturalHeight*target:img.naturalWidth,sh=aspect>target?img.naturalHeight:img.naturalWidth/target;
    // The rounded silhouette belongs to the source, before Gaussian blur.
    // Transparent padding lets its alpha soften beyond the original outline.
    tile.ctx.save();tile.ctx.beginPath();tile.ctx.roundRect(pad,pad,o.width,o.height,6);tile.ctx.clip();
    tile.ctx.drawImage(img,(img.naturalWidth-sw)/2,(img.naturalHeight-sh)/2,sw,sh,pad,pad,o.width,o.height);tile.ctx.restore();
    if(blur>0){
      const source=buffer();resize(source,tile.canvas.width,tile.canvas.height);source.ctx.drawImage(tile.canvas,0,0);
      tile.ctx.clearRect(0,0,tile.canvas.width,tile.canvas.height);tile.ctx.filter=`blur(${blur}px)`;tile.ctx.drawImage(source.canvas,0,0);tile.ctx.filter='none';
    }
    sprites.set(key,tile);return tile;
  }
  function drawSprite(target:CanvasRenderingContext2D,source:Sprite,o:ContactObject,r:{left:number;top:number}) {
    target.drawImage(source.canvas,o.x-r.left-source.inset,o.y-r.top-source.inset);
  }
  function fillGlass(weight:Buffer,renderer:HTMLElement,host:HTMLElement,channel:'blur'|'contrast'|'brightness',r:DOMRect) {
    const layers=renderer.querySelectorAll<HTMLElement>('.glass-blur-layer');
    const index=channel==='blur'?5:channel==='contrast'?6:7;
    const separate=renderer.hasAttribute('data-separate-fades');
    const css=separate?layers[index]?.style.getPropertyValue('--glass-channel-mask'):renderer.style.getPropertyValue('--glass-feather-mask');
    const url=css?imageUrl(css):'';
    if(url){const mask=image(url);if(!mask)return false;const bounds=renderer.getBoundingClientRect(),nine=activeNineSlice(renderer,channel);if(nine)drawNineSlice(weight.ctx,mask,nine,bounds.left-r.left,bounds.top-r.top,bounds.width,bounds.height);else weight.ctx.drawImage(mask,bounds.left-r.left,bounds.top-r.top,bounds.width,bounds.height);}
    else {const bounds=host.getBoundingClientRect(),style=getComputedStyle(host);weight.ctx.fillStyle='#fff';weight.ctx.beginPath();weight.ctx.roundRect(bounds.left-r.left,bounds.top-r.top,bounds.width,bounds.height,['TopLeft','TopRight','BottomRight','BottomLeft'].map(c=>parseFloat(style.getPropertyValue(`border${c}Radius`.replace(/[A-Z]/g,m=>`-${m.toLowerCase()}`)))||0));weight.ctx.fill();}
    return true;
  }
  function field(o:ContactObject){const key=`${o.width}/${o.height}/${o.distance}/${o.mid}/${settings.curve}`;let f=fields.get(key);if(!f){f=featherMask({width:o.width,height:o.height,radius:6,edges:['top','right','bottom','left'],distance:o.distance,mid:o.mid,blur:0,curve:settings.curve});fields.set(key,f);}return f;}
  function subtractExemption(weight:Buffer,o:ContactObject,r:DOMRect){
    if(!o.exempt||o.strength<=0)return true;
    const f=field(o),mask=image(imageUrl(f.url));if(!mask)return false;
    weight.ctx.globalCompositeOperation='destination-out';weight.ctx.globalAlpha=Math.max(0,Math.min(1,o.strength/100));
    weight.ctx.drawImage(mask,o.x-r.left-f.inset[3],o.y-r.top-f.inset[0]);weight.ctx.globalAlpha=1;weight.ctx.globalCompositeOperation='source-over';return true;
  }
  function maskedMix(s:Surface){mixContactLayer(s.object.ctx,s.work.ctx,s.weight.canvas);}
  function paint(){
    frame=0;if(disposed)return;const started=performance.now();
    const finish=beginGlassMeasure('contactPaint');
    const objects=read(),vw=innerWidth,vh=innerHeight;
    if(world.width!==vw)world.width=vw;if(world.height!==vh)world.height=vh;
    // 100% may resolve to a fractional viewport height (e.g. 871.333 at
    // DPR 1.5), while innerHeight rounds. Never stretch this reference pass.
    if(world.style.width!==`${vw}px`)world.style.width=`${vw}px`;
    if(world.style.height!==`${vh}px`)world.style.height=`${vh}px`;
    ctx.clearRect(0,0,vw,vh);ctx.globalCompositeOperation='source-over';
    const renderers=Array.from(document.querySelectorAll<HTMLElement>(`${GLASS_ROOT_SELECTOR} [data-glass] > .glass-renderer`)).filter(n=>!n.closest('[data-glass-transition-copy]'));
    const maxDisplacement=Math.max(0,...Array.from(document.querySelectorAll(`${GLASS_ROOT_SELECTOR} feDisplacementMap`)).map(n=>Number(n.getAttribute('scale'))||0));
    const margin=Math.ceil(settings.values.blur*3+maxDisplacement/2+4);
    for(const o of objects){const base=sprite(o,0);let plane=planes.get(o.id);if(!plane){plane={...buffer(),left:0,top:0};planes.set(o.id,plane);}plane.left=Math.floor(o.x-margin);plane.top=Math.floor(o.y-margin);resize(plane,Math.ceil(o.width+2*margin+1),Math.ceil(o.height+2*margin+1));if(base){drawSprite(ctx,base,o,{left:0,top:0});drawSprite(plane.ctx,base,o,plane);}}
    const seen=new Set<HTMLElement>(),covered:DOMRect[]=[];let reused=0,computed=0;
    const processed=new Map<string,DOMRect[]>();
    const versions=new Map<string,number[]>();
    // Read layout before writing outputs. Only intersecting surfaces need
    // stacking/style queries; a large inspector can contain 60+ other controls.
    const candidates=settings.glassEnabled?renderers.map(renderer=>{const bounds=renderer.getBoundingClientRect();return {renderer,bounds,r:alignedRect(bounds)};}).filter(({renderer,bounds,r})=>bounds.width&&bounds.height&&bounds.bottom>=0&&bounds.top<=vh&&objects.some(o=>overlap(o,r))&&getComputedStyle(renderer).display!=='none'&&getComputedStyle(renderer).visibility!=='hidden'):[];
    const paths=new Map(candidates.map(({renderer})=>[renderer,stackPath(renderer)]));
    candidates.sort((a,b)=>paintOrder(a.renderer,b.renderer,paths)).forEach(({renderer,bounds,r})=>{
      const host=renderer.parentElement!;
      // Every sprite plane, local output and world hole uses the same integer
      // CSS-pixel lattice. Rescaling a ceil-sized canvas into a fractional DOM
      // rect introduces a visible sampling seam through an exempt photograph.
      // A CSS pixel is 1.5 device pixels at common Windows scaling. Align
      // both grids, otherwise each local layer gets a different subpixel
      // resampling phase even when its CSS bounds are integers.
      const relevant=objects.filter(o=>overlap(o,r));if(!relevant.length)return;
      let s=surfaces.get(renderer);
      if(!s){const b=buffer();b.canvas.className='contact-surface-paint';b.canvas.setAttribute('aria-hidden','true');b.canvas.dataset.contactPaint='';
        // Keep the canonical last blur span the last child. Its selector owns
        // the live backdrop pass; z-index puts sprite paint above that pass.
        renderer.insertBefore(b.canvas,renderer.lastElementChild);
        s={...b,work:buffer(),weight:buffer(),fold:buffer(),object:buffer(),layers:new Map()};surfaces.set(renderer,s);}
      seen.add(renderer);s.canvas.style.display='block';
      s.canvas.style.left=`${r.left-bounds.left}px`;s.canvas.style.top=`${r.top-bounds.top}px`;s.canvas.style.width=`${r.width}px`;s.canvas.style.height=`${r.height}px`;
      const w=Math.ceil(r.width),h=Math.ceil(r.height);resize(s,w,h);
      const material=getComputedStyle(renderer),blur=parseFloat(material.getPropertyValue('--glass-blur'))||0;
      const noise=grainOpacity(settings.values.grain,blur);
      const edge=host.style.getPropertyValue('--glass-edge-filter');
      const edgeId=edge.match(/url\(["']?#([^"')]+)["']?\)/)?.[1];
      const filterKey=edgeId?document.getElementById(edgeId)?.outerHTML??edge:'';
      const channelMasks=renderer.hasAttribute('data-separate-fades')?Array.from(renderer.querySelectorAll<HTMLElement>('.glass-blur-layer')).slice(5).map(n=>n.style.getPropertyValue('--glass-channel-mask')).join('|'):'';
      const recipe=[renderer.style.cssText,channelMasks,renderer.getAttribute('data-separate-fades'),material.getPropertyValue('--glass-brightness'),material.getPropertyValue('--glass-contrast'),blur,noise,filterKey].join('/');
      for(const o of relevant){
        const base=sprite(o,0),frost=sprite(o,blur),plane=planes.get(o.id)!;if(!base||!frost)continue;
        const lowerVersions=versions.get(o.id)??[];
        const key=[assetRevision,recipe,r.left,r.top,w,h,bounds.left,bounds.top,bounds.width,bounds.height,o.x,o.y,o.width,o.height,o.exempt,o.strength,o.distance,o.mid,lowerVersions.join(',')].join('/');
        const cached=s.layers.get(o.id);
        if(cached?.key===key){
          reused++;s.ctx.drawImage(cached.canvas,0,0);
          plane.ctx.clearRect(r.left-plane.left,r.top-plane.top,w,h);plane.ctx.drawImage(cached.canvas,r.left-plane.left,r.top-plane.top);
          const lower=processed.get(o.id)??[];lower.push(r);processed.set(o.id,lower);
          lowerVersions.push(cached.version);versions.set(o.id,lowerVersions);continue;
        }
        computed++;
        // Each object carries the result of lower glass surfaces. Upper glass
        // starts with that result, instead of painting a fresh original over it.
        resize(s.object,w,h);s.object.ctx.drawImage(plane.canvas,plane.left-r.left,plane.top-r.top);
        resize(s.work,w,h);
        const lower=processed.get(o.id)??[];
        const stacked=lower.some(p=>p.left<r.right&&p.right>r.left&&p.top<r.bottom&&p.bottom>r.top);
        if(stacked){const pad=Math.ceil(3*blur+2);s.work.ctx.filter=`blur(${blur}px)`;s.work.ctx.drawImage(plane.canvas,r.left-pad-plane.left,r.top-pad-plane.top,w+2*pad,h+2*pad,-pad,-pad,w+2*pad,h+2*pad);s.work.ctx.filter='none';}
        else drawSprite(s.work.ctx,frost,o,r);
        if(edge){resize(s.fold,w,h);s.fold.ctx.filter=edge;s.fold.ctx.drawImage(s.work.canvas,0,0);s.work.ctx.clearRect(0,0,w,h);s.work.ctx.drawImage(s.fold.canvas,0,0);s.fold.ctx.filter='none';}
        resize(s.weight,w,h);if(!fillGlass(s.weight,renderer,host,'blur',r))continue;
        if(!subtractExemption(s.weight,o,r))continue;
        maskedMix(s);
        // Tone is isolated before object stacking, so overlapping sources
        // cannot borrow one another's field. Every channel keeps its own fade.
        for(const channel of ['contrast','brightness'] as const){
          const parsed=parseFloat(material.getPropertyValue(`--glass-${channel}`)),value=Number.isFinite(parsed)?parsed:1;if(value===1)continue;
          resize(s.work,w,h);s.work.ctx.filter=`${channel}(${value})`;s.work.ctx.drawImage(s.object.canvas,0,0);s.work.ctx.filter='none';
          // Shared feathers reuse the already attenuated alpha, avoiding two
          // extra field composites per sprite on the common/default path.
          if(renderer.hasAttribute('data-separate-fades')){resize(s.weight,w,h);if(!fillGlass(s.weight,renderer,host,channel,r)||!subtractExemption(s.weight,o,r))continue;}
          maskedMix(s);
        }
        // Surface roughness remains even at full contact: grain follows only
        // the glass blur alpha, never the object's exemption field.
        const texture=grain??image(grainUrl);
        if(noise>0&&texture){
          resize(s.work,w,h);s.work.ctx.drawImage(s.object.canvas,0,0);
          let pattern=grainPatterns.get(s.work.ctx);if(!pattern){pattern=s.work.ctx.createPattern(texture,'repeat')!;grainPatterns.set(s.work.ctx,pattern);}
          s.work.ctx.globalCompositeOperation='soft-light';s.work.ctx.globalAlpha=noise;s.work.ctx.fillStyle=pattern;s.work.ctx.fillRect(0,0,w,h);s.work.ctx.globalAlpha=1;
          s.work.ctx.globalCompositeOperation='destination-in';s.work.ctx.drawImage(s.object.canvas,0,0);s.work.ctx.globalCompositeOperation='source-over';
          resize(s.weight,w,h);if(fillGlass(s.weight,renderer,host,'blur',r))maskedMix(s);
        }
        s.ctx.drawImage(s.object.canvas,0,0);
        const result=cached??{...buffer(),key:'',version:0};resize(result,w,h);result.ctx.drawImage(s.object.canvas,0,0);result.key=key;result.version=++layerVersion;s.layers.set(o.id,result);
        lowerVersions.push(result.version);versions.set(o.id,lowerVersions);
        plane.ctx.clearRect(r.left-plane.left,r.top-plane.top,w,h);plane.ctx.drawImage(s.object.canvas,r.left-plane.left,r.top-plane.top);
        lower.push(r);processed.set(o.id,lower);
      }
      s.canvas.dataset.contactObjects=relevant.map(o=>o.id).join(' ');
      covered.push(r);
      ctx.globalCompositeOperation='destination-out';ctx.fillRect(r.left,r.top,r.width,r.height);ctx.globalCompositeOperation='source-over';
    });
    surfaces.forEach((s,r)=>{if(!r.isConnected){s.canvas.remove();surfaces.delete(r);}else if(!seen.has(r)){s.canvas.style.display='none';}});
    // Preserve caption paint above sprites without cutting rectangular holes
    // through the photos. Invert captions already use the top difference layer.
    if(document.documentElement.dataset.textColor!=='invert')document.querySelectorAll<HTMLElement>('.geometry-caption glass-text,.showcase-title glass-text,.showcase-footer glass-text').forEach(n=>{
      if(n.closest('[data-glass]'))return;
      const r=n.getBoundingClientRect();if(!objects.some(o=>overlap(o,r)))return;
      const style=getComputedStyle(n);ctx.font=`${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;ctx.fillStyle=style.color;ctx.textBaseline='middle';ctx.fillText(n.textContent??'',r.left,r.top+r.height/2);
    });
    ctx.globalCompositeOperation='destination-out';covered.forEach(r=>ctx.fillRect(r.left,r.top,r.width,r.height));ctx.globalCompositeOperation='source-over';
    world.dataset.paintCount=String(Number(world.dataset.paintCount??0)+1);world.dataset.activeSurfaces=String(seen.size);
    world.dataset.paintMs=(performance.now()-started).toFixed(2);
    world.dataset.reusedLayers=String(reused);world.dataset.computedLayers=String(computed);
    finish?.();
    if(moving.size)schedule();
  }
  const observer=new MutationObserver(records=>{if(records.some(record=>{
    const node=record.target;if(!(node instanceof Element))return record.type==='childList'&&Array.from(record.addedNodes).some(n=>n instanceof Element&&n.querySelector('[data-glass]'));
    if(node.hasAttribute('data-contact-paint')||node.matches('.contact-world-paint')||node.closest('.glass-reveal-stage,.doppler-range,[data-instrument-display]'))return false;
    if(record.type==='childList')return [...record.addedNodes,...record.removedNodes].some(n=>n instanceof Element&&(n.matches('[data-glass],.glass-renderer')||n.querySelector('[data-glass],.glass-renderer')));
    return node.matches('[data-glass],.glass-renderer,.glass-blur-layer,.glass-select-popover,html')||Boolean(node.closest('.glass-refraction-defs'));
  }))schedule();});
  observer.observe(getGlassRoot(),{subtree:true,childList:true,attributes:true,attributeFilter:['style','class','data-feather-mask','data-separate-fades','href','scale','stdDeviation']});
  observer.observe(document.documentElement,{attributes:true,attributeFilter:['style','class','data-text-color']});
  const phase=(event:Event)=>{if(event instanceof CustomEvent&&event.target instanceof HTMLElement){if(event.detail.phase==='moving')moving.add(event.target);else moving.delete(event.target);}schedule();};
  document.addEventListener('glassrevealphase',phase);
  document.addEventListener('glassboxresize',schedule);
  window.addEventListener('resize',schedule);document.addEventListener('scroll',schedule,true);
  schedule();
  return {schedule,destroy(){disposed=true;cancelAnimationFrame(frame);observer.disconnect();window.removeEventListener('resize',schedule);document.removeEventListener('scroll',schedule,true);document.removeEventListener('glassrevealphase',phase);document.removeEventListener('glassboxresize',schedule);surfaces.forEach(s=>s.canvas.remove());images.forEach(i=>{i.onload=null;});}};
}
