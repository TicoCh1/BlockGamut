/** Only a disclosure's shared layout row participates, never unrelated page cards. */
export function revealLayoutPeers(host:HTMLElement,root:HTMLElement):HTMLElement[]{
  const before=host.getBoundingClientRect();
  for(let parent=host.parentElement;parent&&parent!==root;parent=parent?.parentElement??null){
    const style=getComputedStyle(parent);
    if(!['grid','inline-grid','flex','inline-flex'].includes(style.display))continue;
    return Array.from(parent.querySelectorAll<HTMLElement>('[data-glass-component="panel"]')).filter(node=>{
      if(node.contains(host)||host.contains(node))return false;
      if(style.display.includes('flex')&&style.flexDirection.startsWith('column'))return true;
      const other=node.getBoundingClientRect();
      return other.top<before.bottom&&other.bottom>before.top;
    });
  }
  return [];
}
