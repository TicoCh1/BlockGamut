// Measured from the supplied drawing: 455px centre height, 190px mouth
// height, 13px uniform pen width, 44px centre-to-mouth spacing. One scale
// applies to the flare; the centre path is subsequently shortened by 15%.
// The idle flare is still an exact quarter-circle.
const scale=24/455;
export const RANGE_PROFILE={
  centreHalf:221*scale*.85,
  stroke:13*scale,
  gap:44*scale,
  radius:88.5*scale
} as const;

/** Normalized signed speed; retain a useful range above ordinary dragging. */
export function rangeMotionForSpeed(pixelsPerSecond:number) {
  return Math.max(-3,Math.min(3,Number.isFinite(pixelsPerSecond)?pixelsPerSecond/600:0));
}

/** Positive motion moves right: the left flare trails and stretches. */
export function rangeLobes(motion: number) {
  const amount=Math.max(-3,Math.min(3,Number.isFinite(motion)?motion:0));
  const rightward=Math.max(amount,0), leftward=Math.max(-amount,0);
  const rightHeight=Math.min(rightward,1), leftHeight=Math.min(leftward,1);
  const {gap,radius}=RANGE_PROFILE;
  return {
    left:gap+radius*(1+rightward*1.3-leftHeight*.4),
    right:gap+radius*(1+leftward*1.3-rightHeight*.4),
    leftHeight:radius*(1-rightHeight*.25+leftHeight*.5),
    rightHeight:radius*(1-leftHeight*.25+rightHeight*.5)
  };
}

/** Quarter-ellipse flare: horizontal tangent at the thin rail, vertical
 * tangent at the mouth. Both curved sides join a flat, rounded mouth beside
 * the centre stroke, rather than converging to an arrow's pointed tip. */
export function rangeLobePath(length:number, height:number) {
  const {gap}=RANGE_PROFILE, tail=-Math.max(length,gap+.1), radiusX=-tail-gap;
  return `M${tail} 0A${radiusX} ${height} 0 0 0 ${-gap} ${-height}L${-gap} ${height}A${radiusX} ${height} 0 0 0 ${tail} 0Z`;
}
