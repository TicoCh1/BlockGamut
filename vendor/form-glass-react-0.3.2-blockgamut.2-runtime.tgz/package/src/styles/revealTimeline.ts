import { glassFadeProgress, type GlassFadeCurve } from './glassFade.ts';
export const GLASS_REVEAL_DURATION=250;
export const GLASS_CONTENT_FADE_DURATION=500;
export const DEFAULT_DEMO_FADE_CURVE='smootherstep' as const;
export function revealProgress(from:number,to:number,time:number,curve:GlassFadeCurve='smootherstep') {
  return from+(to-from)*glassFadeProgress(time,curve);
}
export function revealContentFrames(from:number,to:number,fromBlur=(1-from)*64,toBlur=(1-to)*64,timing?:{split:number;hiding:boolean;curve:GlassFadeCurve}) {
  const hiding=timing?.hiding??(toBlur>fromBlur||to<from),split=timing?.split??.5,curve=timing?.curve??'smootherstep';
  return Array.from({length:61},(_,i)=>{
    const t=i/60;
    // Disappear: blur completely, then fade. Appear is the exact reverse:
    // become visible while still blurred, then gather into sharp detail.
    const first=split>0?Math.min(1,t/split):1,second=split<1?Math.max(0,(t-split)/(1-split)):Number(t>=1);
    const opacityTime=hiding?second:first,blurTime=hiding?first:second;
    return {offset:t,opacity:revealProgress(from,to,opacityTime,curve),filter:`blur(${revealProgress(fromBlur,toBlur,blurTime,curve)}px)`};
  });
}
/** The real material/refraction outline moves with the shell itself. There is
 * no independent scanning strip. Close retraces the exact expansion path. */
export function revealFrames(from:number,to:number,compactX:number,compactY:number,curve:GlassFadeCurve='smootherstep') {
  const panel:Keyframe[]=[];
  for(let i=0;i<=60;i++){
    const t=i/60,p=revealProgress(from,to,t,curve);
    panel.push({offset:t,transform:`scale(${compactX+(1-compactX)*p},${compactY+(1-compactY)*p})`});
  }
  return panel;
}

export type RevealBox={width:number;height:number;left?:number;top?:number};
export function fitRevealSeed(box:RevealBox,minimum:{width:number;height:number},pinned=false):RevealBox{
  const width=Math.max(box.width,minimum.width),height=Math.max(box.height,minimum.height);
  // DOMRect positions live on its prototype. Copy coordinates explicitly and
  // preserve the trigger centre when channel constraints enlarge the seed.
  return {width,height,left:pinned||box.left===undefined?undefined:box.left+(box.width-width)/2,top:pinned||box.top===undefined?undefined:box.top+(box.height-height)/2};
}
/** Animate the material's real box, not a scaled rounded rectangle. A seed
 * always contains a circle of the final corner radius; translate and size
 * share one progress value, including when closing back to the trigger. */
export function revealGeometryFrames(from:number,to:number,full:RevealBox,seed:RevealBox,radius:number,origin:{x:number;y:number},curve:GlassFadeCurve='smootherstep') {
  const diameter=2*Math.max(0,Math.min(radius,full.width/2,full.height/2));
  const width=Math.min(full.width,Math.max(diameter,seed.width));
  const height=Math.min(full.height,Math.max(diameter,seed.height));
  const dx=seed.left===undefined?(full.width-width)*origin.x:seed.left+(seed.width-width)/2-(full.left??0);
  const dy=seed.top===undefined?(full.height-height)*origin.y:seed.top+(seed.height-height)/2-(full.top??0);
  return Array.from({length:61},(_,i)=>{
    const t=i/60,p=revealProgress(from,to,t,curve);
    return {offset:t,width:`${width+(full.width-width)*p}px`,height:`${height+(full.height-height)*p}px`,transform:`translate(${dx*(1-p)}px,${dy*(1-p)}px)`};
  });
}
