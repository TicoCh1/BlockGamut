import { featherMask, type FeatherGeometry } from './featherMask.ts';
import type { GlassValues } from './glassSettings.ts';

export const MATERIAL_CHANNELS = ['blur', 'contrast', 'brightness'] as const;
export type MaterialChannel = typeof MATERIAL_CHANNELS[number];
export type ChannelFade = { distance: number; mid: number };
export type MaterialFades = Record<MaterialChannel, ChannelFade>;

export function materialFades(values: GlassValues): MaterialFades {
  return {
    blur: { distance: values['fade-distance'], mid: values['fade-mid'] },
    contrast: { distance: values['contrast-fade-distance'], mid: values['contrast-fade-mid'] },
    brightness: { distance: values['brightness-fade-distance'], mid: values['brightness-fade-mid'] }
  };
}
export function sameMaterialFades(fades: MaterialFades) {
  return MATERIAL_CHANNELS.every(channel => fades[channel].distance === fades.blur.distance && (fades[channel].distance === 0 || fades[channel].mid === fades.blur.mid));
}

/** All endpoint masks share one sampling rectangle, so sequential backdrop
 * filters and the optional bend use identical coordinates. No pixels cached. */
export function alignedMaterialMasks(geometry: Omit<FeatherGeometry, 'distance' | 'mid'>, fades: MaterialFades) {
  const masks = MATERIAL_CHANNELS.map(channel => featherMask({ ...geometry, ...fades[channel], mid: fades[channel].distance > 0 ? fades[channel].mid : 0 }));
  const inset = [0, 1, 2, 3].map(i => Math.max(...masks.map(mask => mask.inset[i])));
  const width = geometry.width + inset[1] + inset[3], height = geometry.height + inset[0] + inset[2];
  const urls = Object.fromEntries(masks.map((mask, i) => {
    const body = mask.svg.replace(/^<svg[^>]*>/, '').replace(/<\/svg>$/, '');
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}"><g transform="translate(${inset[3] - mask.inset[3]} ${inset[0] - mask.inset[0]})">${body}</g></svg>`;
    return [MATERIAL_CHANNELS[i], `url("data:image/svg+xml,${encodeURIComponent(svg)}")`];
  })) as Record<MaterialChannel, string>;
  return { inset, urls, empty: Object.fromEntries(masks.map((mask,i)=>[MATERIAL_CHANNELS[i],mask.empty])) as Record<MaterialChannel,boolean> };
}
