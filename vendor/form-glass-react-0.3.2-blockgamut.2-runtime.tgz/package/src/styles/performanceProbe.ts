/** Bounded consumer QA opts in; production does not collect timings. */
export function beginGlassMeasure(name:string){
  if(typeof document==='undefined'||!document.documentElement.hasAttribute('data-glass-profile'))return undefined;
  const start=performance.now();
  return ()=>document.dispatchEvent(new CustomEvent('glassprofilemeasure',{detail:{name,start,duration:performance.now()-start}}));
}
