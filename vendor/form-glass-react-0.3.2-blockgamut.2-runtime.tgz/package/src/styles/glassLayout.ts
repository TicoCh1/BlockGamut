/** The material belongs to the layout box, not its animated scale. Preserve
 * fractional CSS geometry while avoiding transformed bounding-box reads. */
export function glassLayoutBox(node:HTMLElement,style=getComputedStyle(node)) {
  const extra=(axis:'width'|'height')=>style.boxSizing==='border-box'?0:(axis==='width'?['paddingLeft','paddingRight','borderLeftWidth','borderRightWidth']:['paddingTop','paddingBottom','borderTopWidth','borderBottomWidth']).reduce((sum,key)=>sum+(parseFloat(style[key as keyof CSSStyleDeclaration] as string)||0),0);
  return {width:(parseFloat(style.width)||node.offsetWidth)+extra('width'),height:(parseFloat(style.height)||node.offsetHeight)+extra('height')};
}
