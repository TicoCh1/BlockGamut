import { syncGlassFadeMode } from './glassFade';
import { grainOpacity } from './grain';

export const GLASS_PARAMETERS = [
  { key: 'blur', label: 'Glass blur', min: 0, max: 64, step: 1, unit: 'px' },
  { key: 'fade-distance', label: 'Blur fade distance', min: 0, max: 64, step: 1, unit: 'px' },
  { key: 'fade-mid', label: 'Blur fade mid', min: -64, max: 64, step: .5, unit: 'px' },
  { key: 'grain', label: 'Grain intensity', min: 0, max: 100, step: 1, unit: '%' },
  { key: 'brightness', label: 'Glass brightness', min: -100, max: 200, step: .1, unit: '%' },
  { key: 'brightness-fade-distance', label: 'Brightness fade distance', min: 0, max: 64, step: 1, unit: 'px' },
  { key: 'brightness-fade-mid', label: 'Brightness fade mid', min: -64, max: 64, step: .5, unit: 'px' },
  { key: 'contrast', label: 'Glass contrast', min: 0, max: 2, step: .01, unit: '' },
  { key: 'contrast-fade-distance', label: 'Contrast fade distance', min: 0, max: 64, step: 1, unit: 'px' },
  { key: 'contrast-fade-mid', label: 'Contrast fade mid', min: -64, max: 64, step: .5, unit: 'px' }
] as const;
export type GlassValues = Record<typeof GLASS_PARAMETERS[number]['key'], number>;
export type GlassParameter = typeof GLASS_PARAMETERS[number]['key'];

export function updateGlassParameter(values: GlassValues, key: GlassParameter, value: number): GlassValues {
  return { ...values, [key]: value };
}

export function clearGlassTuning() {
  for (const { key } of GLASS_PARAMETERS) document.documentElement.style.removeProperty(`--glass-debug-${key}`);
  document.documentElement.style.removeProperty('--glass-control-blur');
  document.documentElement.style.removeProperty('--glass-control-brightness');
  document.documentElement.style.removeProperty('--glass-grain-opacity');
  syncGlassFadeMode();
}

// App presets use the unchanged shared renderer. Brightness is signed percent.
// Selected fade edges start at 32px with a -16px inward shift; empty edges stay solid.
export function readGlassDefaults(darkMode: boolean): GlassValues {
  return { blur: 8, grain:25, brightness: darkMode ? -40 : 40, contrast: darkMode ? 1.4 : .6, 'fade-distance': 32, 'fade-mid': -16, 'brightness-fade-distance': 32, 'brightness-fade-mid': -16, 'contrast-fade-distance': 32, 'contrast-fade-mid': -16 };
}

export function applyGlassTuning(values: GlassValues) {
  const root = document.documentElement;
  const brightness = 1 + values.brightness / 100;
  const contrast = values.contrast;
  root.style.setProperty('--glass-debug-blur', `${values.blur}px`);
  // Frost grain is material detail, proportional to blur and capped gently.
  root.style.setProperty('--glass-grain-opacity', String(grainOpacity(values.grain,values.blur)));
  root.style.setProperty('--glass-debug-fade-distance', `${values['fade-distance']}px`);
  root.style.setProperty('--glass-debug-fade-mid', `${values['fade-mid']}px`);
  root.style.setProperty('--glass-debug-brightness', String(brightness));
  root.style.setProperty('--glass-debug-contrast', String(contrast));
  // Use the source control compensation with the currently tuned panel tone.
  const strength = parseFloat(getComputedStyle(root).getPropertyValue('--glass-control-tone-strength'));
  root.style.setProperty('--glass-control-brightness', String(brightness > 0 ? (1 + (brightness - 1) * strength) / brightness : 1));
  root.style.setProperty('--glass-control-blur', `${values.blur}px`);
  syncGlassFadeMode();
}
